package com.scb.channels.foundation.contentcache.service;


import com.google.common.collect.ImmutableList;
import com.scb.channels.foundation.contentcache.repository.ResourceRepository;
import com.scb.channels.foundation.contentcache.util.TestData;
import com.scb.channels.foundation.entitlement.dap.DapPolicyFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContentCacheServiceImplTest {

    @Mock
    private ResourceRepository resourceRepository;

    @Mock
    private DapPolicyFactory dapPolicyFactory;

    @Test
    public void should_not_check_dap_when_dapplugin_issuppressed() {
        ContentCacheServiceImpl service = new ContentCacheServiceImpl(resourceRepository, "false");
        when(resourceRepository.loadSummaryByClassification(any())).thenReturn(ImmutableList.of(TestData.resourceSummary("12", 1, "application/json")));
        service.resourceByClassification("rp", "classification", null);
        verify(dapPolicyFactory, times(0)).create(anyString());
    }
}
