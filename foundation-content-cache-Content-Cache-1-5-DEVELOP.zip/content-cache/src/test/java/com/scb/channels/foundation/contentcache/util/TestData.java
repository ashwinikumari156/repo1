package com.scb.channels.foundation.contentcache.util;

import com.datastax.driver.core.utils.UUIDs;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.util.jackson.JacksonMarshaller;
import com.scb.channels.foundation.util.jackson.Marshaller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.UUID;

public class TestData {

    private static final Logger LOG = LoggerFactory.getLogger(TestData.class);

    public static String TEST_CONTENT_ID = UUID.randomUUID().toString();
    private static Marshaller marshaller = new JacksonMarshaller();

    public static ResourceSummary resourceSummary(String resourceId, int size, String contentType) {
        return ResourceSummary.builder()
                .applicationId("appId")
                .classification("classification")
                .subClassification("subClassification")
                .contentType((contentType == null) ? "application/json" : contentType)
                .id("appId:subClassification:classification:"+resourceId)
                .resourceId(resourceId)
                .createdAt(Instant.now())
                .receivedAt(Instant.now())
                .size(size)
                .build();
    }

    public static ResourceSummary resourceSummary(String resourceId, int size, String contentType, String md5Hash) {
        return ResourceSummary.builder()
                .applicationId("appId")
                .classification("classification")
                .subClassification("subClassification")
                .contentType((contentType == null) ? "application/json" : contentType)
                .id("appId:subClassification:classification:"+resourceId)
                .resourceId(resourceId)
                .createdAt(Instant.now())
                .receivedAt(Instant.now())
                .size(size)
                .md5hash(md5Hash)
                .build();
    }

    public static ResourceIdentifier identifier(String resourceId) {
        return ResourceIdentifier.builder()
                .applicationId("appId")
                .resourceId(resourceId)
                .classification("classification")
                .subClassification("subClassification")
                .build();
    }

    public static String getContent() {
        return FileUtils.getFileContent.apply("content.json");
    }

    public static Readership readership() {
        return Readership.builder()
                .id(UUIDs.timeBased()+"")
                .applicationId("applicationId")
                .resourceId("resourceId")
                .userId("userId")
                .createdAt(Instant.now())
                .build();
    }
}

