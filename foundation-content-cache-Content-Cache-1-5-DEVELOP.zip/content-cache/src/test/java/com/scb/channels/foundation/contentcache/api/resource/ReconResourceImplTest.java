package com.scb.channels.foundation.contentcache.api.resource;

import com.datastax.driver.core.Session;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.api.dto.recon.ReconHeaders;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.ResourceRepositoryImpl;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import com.scb.channels.foundation.contentcache.service.ContentCacheServiceImpl;
import com.scb.channels.foundation.contentcache.util.TestData;
import com.scb.channels.foundation.util.encryption.HashingUtil;
import com.scb.channels.persistence.PersistenceServiceImpl;
import com.scb.channels.persistence.cassandra.CassandraConfig;
import com.scb.channels.persistence.cassandra.CassandraStore;
import net.minidev.json.JSONObject;
import org.apache.thrift.transport.TTransportException;
import org.cassandraunit.utils.EmbeddedCassandraServerHelper;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class ReconResourceImplTest {
    private static Session session;
    ContentCacheService contentCacheService;
    ContentCacheContext contentCacheContext;
    private ResourceRepositoryImpl resourceRepository;
    private PersistenceServiceImpl persistenceService;
    private CassandraConfig cassandraConfig;

    final String ID = "1";

    ReconResourceImpl underTest;

    private static String USERID = "GSGSCBSE/4243632";
    private static String DAPPOLICY = "Research";

    @Before
    public void before() {
        cassandraConfig = new CassandraConfig();
        cassandraConfig.setKeyspace("CONTENT_CACHE");
        persistenceService = new PersistenceServiceImpl(new CassandraStore(cassandraConfig, session));
        resourceRepository = new ResourceRepositoryImpl(persistenceService);
        session.execute("TRUNCATE resource_by_id");
        contentCacheService = new ContentCacheServiceImpl(resourceRepository, DAPPOLICY);
        contentCacheContext = new ContentCacheContext(USERID, DAPPOLICY);

        underTest = new ReconResourceImpl(resourceRepository, contentCacheContext);
    }

    @Test
    public void recon_not_required() throws JsonProcessingException {
        //Setup data
        ResourceSummary resourceSummary = setup1SimpleData(ID);
        ResourceIdentifier identifier = TestData.identifier(ID);
        List<String> reconIds = new ArrayList<>();
        reconIds.add(identifier.getResourceId());

        ReconHeaders headers = ReconHeaders.builder()
                                            .applicationId(resourceSummary.getApplicationId())
                                            .entityType(resourceSummary.getClassification())
                                            .subCategory(resourceSummary.getSubClassification())
                                            .md5hash(resourceSummary.getMd5hash())
                                            .identifiers(reconIds)
                                            .timestamp(resourceSummary.getCreatedAt().getEpochSecond())
                                            .build();

        ReconHeaderRequest request = new ReconHeaderRequest(headers);

        ReconHeaderResponse response = underTest.resolveReconHeaders(request);
        assertEquals(0, response.getHdrsToUpdate().size());
        assertEquals(0, response.getHdrsToDeactivate().size());
    }

    @Test
    public void no_recon_earlier_Objects() throws JsonProcessingException {
        ResourceSummary resourceSummary = setup1SimpleData(ID);
        ResourceIdentifier identifier = TestData.identifier(ID);

        List<String> reconIds = new ArrayList<>();
        reconIds.add(identifier.getResourceId());
        ReconHeaders headers = ReconHeaders.builder()
                .applicationId(resourceSummary.getApplicationId())
                .entityType(resourceSummary.getClassification())
                .subCategory(resourceSummary.getSubClassification())
                .md5hash(resourceSummary.getMd5hash())
                .identifiers(reconIds)
                .timestamp(resourceSummary.getCreatedAt().minus(1, ChronoUnit.DAYS).getEpochSecond())
                .build();

        ReconHeaderRequest request = new ReconHeaderRequest(headers);
        ReconHeaderResponse response = underTest.resolveReconHeaders(request);
        assertEquals(0, response.getHdrsToUpdate().size());
        assertEquals(0, response.getHdrsToDeactivate().size());
    }

    @Test
    public void ObjectsCreatedLaterShouldUpdate() throws JsonProcessingException {
        ResourceSummary resourceSummary = setup1SimpleData(ID);
        ResourceIdentifier identifier = TestData.identifier(ID);

        List<String> reconIds = new ArrayList<>();
        reconIds.add(identifier.getResourceId());
        ReconHeaders headers = ReconHeaders.builder()
                .applicationId(resourceSummary.getApplicationId())
                .entityType(resourceSummary.getClassification())
                .subCategory(resourceSummary.getSubClassification())
                .md5hash(resourceSummary.getMd5hash())
                .identifiers(reconIds)
                .timestamp(resourceSummary.getCreatedAt().plus(1, ChronoUnit.DAYS).getEpochSecond())
                .build();

        ReconHeaderRequest request = new ReconHeaderRequest(headers);
        ReconHeaderResponse response = underTest.resolveReconHeaders(request);
        assertEquals(1, response.getHdrsToUpdate().size());
        assertEquals(0, response.getHdrsToDeactivate().size());
    }


    @Test
    public void newObjectsShouldUpdate_OldObjects_ShouldDeactivate() throws JsonProcessingException {
        ResourceSummary resourceSummary = setup1SimpleData(ID);
        ResourceIdentifier identifier = TestData.identifier("2");

        List<String> reconIds = new ArrayList<>();
        reconIds.add(identifier.getResourceId());
        ReconHeaders headers = ReconHeaders.builder()
                .applicationId(resourceSummary.getApplicationId())
                .entityType(resourceSummary.getClassification())
                .subCategory(resourceSummary.getSubClassification())
                .md5hash("2sDifferentMd5Hash")
                .identifiers(reconIds)
                .timestamp(resourceSummary.getCreatedAt().getEpochSecond())
                .build();

        ReconHeaderRequest request = new ReconHeaderRequest(headers);
        ReconHeaderResponse response = underTest.resolveReconHeaders(request);
        assertEquals(1, response.getHdrsToUpdate().size());
        assertEquals(1, response.getHdrsToDeactivate().size());
    }

    private static JSONObject simplePayload(String id) {
        JSONObject object = new JSONObject();
        object.put("id", id);

        return object;
    }

    private ResourceSummary setup1SimpleData(String id){
        JSONObject payload1 = simplePayload(id);
        String md5 = HashingUtil.generateMD5(payload1.toJSONString());
        ResourceSummary resourceSummary = TestData.resourceSummary(id, 1000, null, md5);
        ResourceEntity entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(payload1.toJSONString().getBytes()));
        resourceRepository.persistResource(entity);
        return resourceSummary;
    }

    @BeforeClass
    public static void startCassandraAndCreateSchema() throws InterruptedException, IOException, TTransportException {
        EmbeddedCassandraServerHelper.startEmbeddedCassandra(60000);

        InputStream schemaScript = ReconResourceImplTest.class.getClassLoader().getResourceAsStream("database/001_schema_create.cql");

        session = EmbeddedCassandraServerHelper.getSession();

        session.execute("CREATE KEYSPACE CONTENT_CACHE WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 1}");
        session.execute("USE CONTENT_CACHE");

        StringBuilder sb = new StringBuilder();
        try(LineNumberReader reader = new LineNumberReader(new InputStreamReader(schemaScript))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                if (line.endsWith(";")) {
                    session.execute(sb.toString());
                    sb.setLength(0);
                }
            }
        }

    }

    @AfterClass
    public static void tearDown() {
        EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
    }
}
