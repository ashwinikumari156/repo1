package com.scb.channels.foundation.contentcache.util;

import com.scb.channels.persistence.Loadable;
import org.mockito.ArgumentMatcher;

import java.util.Objects;

public class PersistenceMatchers {
    private PersistenceMatchers() {}

    public static <T> ArgumentMatcher<Loadable<T>> loadsFrom(String targetTable) {
        return argument -> argument != null && Objects.equals(targetTable, argument.targetTable());
    }
}
