package com.scb.channels.foundation.contentcache.consumer;

import com.google.common.collect.ImmutableMap;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceFragment;
import com.scb.channels.foundation.contentcache.repository.ResourceRepository;
import com.scb.channels.foundation.contentcache.util.ContentCacheConstants;
import com.scb.channels.foundation.models.ContentDescriptor;
import com.scb.channels.foundation.models.Header;
import com.scb.channels.foundation.models.Message;
import com.scb.channels.foundation.util.jackson.JacksonMarshaller;
import com.scb.channels.foundation.util.jackson.Marshaller;
import org.junit.*;
import org.mockito.Mockito;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.KafkaMessageListenerContainer;
import org.springframework.kafka.listener.MessageListener;
import org.springframework.kafka.listener.config.ContainerProperties;
import org.springframework.kafka.test.rule.KafkaEmbedded;
import org.springframework.kafka.test.utils.ContainerTestUtils;
import org.springframework.kafka.test.utils.KafkaTestUtils;

import javax.ws.rs.core.MediaType;
import java.time.Instant;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.internal.verification.VerificationModeFactory.times;


public class MessageHandlerImplTest {

    /*
      Common Kafka Test code, if you copy-paste this class, keep this !
     */
    private static final String TEST_TOPIC = "test-topic";

    @ClassRule
    public static KafkaEmbedded embeddedKafka = new KafkaEmbedded(1, true, TEST_TOPIC);

    private static String kafkaBootstrapServers;
    private static KafkaMessageListenerContainer<Integer, String> container = null;
    private static KafkaTemplate<Integer,String> sender;
    private CountDownLatch triggerCountdown = new CountDownLatch(1);

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        kafkaBootstrapServers = embeddedKafka.getBrokersAsString();
        System.setProperty("kafka.bootstrap.servers", kafkaBootstrapServers);
        sender = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(ImmutableMap.of(
                "bootstrap.servers",kafkaBootstrapServers,
                "key.serializer", "org.apache.kafka.common.serialization.StringSerializer",
                "value.serializer", "org.apache.kafka.common.serialization.StringSerializer")));
    }

    private void setUpConsumer(Consumer<String> messageConsumer) throws Exception {
        Map<String, Object> consumerProperties = KafkaTestUtils.consumerProps("test_group", "false", embeddedKafka);
        DefaultKafkaConsumerFactory<Integer, String> consumerFactory = new DefaultKafkaConsumerFactory<>(consumerProperties);
        ContainerProperties containerProperties = new ContainerProperties(TEST_TOPIC);
        container = new KafkaMessageListenerContainer<>(consumerFactory, containerProperties);

        container.setupMessageListener(
                (MessageListener<Integer, String>) record -> {
                    messageConsumer.accept(record.value());
                    triggerCountdown.countDown();
                });
        container.start();
        ContainerTestUtils.waitForAssignment(container, embeddedKafka.getPartitionsPerTopic());
    }


    /*
        Test specific code (delete this)
     */
    private ResourceRepository resourceRepository = mock(ResourceRepository.class);
    private Marshaller marshaller = new JacksonMarshaller();
    private MessageHandler messageHandler;

    @Before
    public void setup_message_subscriber() throws Exception {
        messageHandler = new MessageHandlerImpl(resourceRepository, marshaller);
        setUpConsumer(s -> messageHandler.processMessage(s));
    }

    @After
    public void stop_container() {
        container.stop();
    }

    @Test
    public void fragment_should_be_persisted() throws Exception {
        Message message = createEntity(true);
        sender.send(TEST_TOPIC, marshaller.marshalLenient(message));
        triggerCountdown.await(1, TimeUnit.SECONDS);
        Mockito.verify(resourceRepository,times(1)).persistFragment(any(ResourceFragment.class));
        Mockito.verify(resourceRepository,times(0)).persistResource(any(ResourceEntity.class));
    }

    @Test
    public void non_fragment_should_be_persisted() throws Exception {
        Message message = createEntity(false);
        sender.send(TEST_TOPIC, marshaller.marshalLenient(message));
        triggerCountdown.await(1, TimeUnit.SECONDS);
        Mockito.verify(resourceRepository,times(0)).persistFragment(any(ResourceFragment.class));
        Mockito.verify(resourceRepository,times(1)).persistResource(any(ResourceEntity.class));
    }

    private Message createEntity(boolean isFragment) {
        return Message.builder()
                .contentDescriptor(simpleCompressedContent())
                .header(Header.builder()
                        .applicationId("appId")
                        .action("action")
                        .category("category")
                        .documentId("1")
                        .fragment(isFragment)
                        .finalFragment(isFragment)
                        .fragmentIndex(0)
                        .messageTimestamp(Instant.now())
                        .messageID(UUID.randomUUID().toString())
                        .sourceSystem("test")
                        .subCategory("subcat")
                        .version("v1").build()).build();
    }

    private ContentDescriptor simpleCompressedContent() {
        byte[] bytes = new byte[ContentCacheConstants.MAX_CHUNK_SIZE];
        new Random().nextBytes(bytes);
        return ContentDescriptor.compress(bytes, MediaType.APPLICATION_OCTET_STREAM);
    }



}