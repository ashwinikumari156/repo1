package com.scb.channels.foundation.contentcache.api.dto;

import com.scb.channels.foundation.contentcache.model.ResourceSummary;

import java.time.Instant;

public class ResourceLink {

    private String subClassification;
    private String applicationId;
    private String classification;
    private Instant createdAt;
    private String resourceId;
    private String contentType;
    private int size;

    public ResourceLink() {

    }

    public ResourceLink(ResourceSummary resource) {
        this.classification = resource.getClassification();
        this.subClassification = resource.getSubClassification();
        this.resourceId = resource.getResourceId();
        this.contentType = resource.getContentType();
        this.applicationId = resource.getApplicationId();
        this.createdAt = resource.getCreatedAt();
        this.size = resource.getSize();
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getSubClassification() {
        return subClassification;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getContentType() {
        return contentType;
    }

    public String getClassification() {
        return classification;
    }

    public int getSize() {
        return size;
    }

    public static ResourceLink from(ResourceSummary r) {
        return new ResourceLink(r);
    }
}
