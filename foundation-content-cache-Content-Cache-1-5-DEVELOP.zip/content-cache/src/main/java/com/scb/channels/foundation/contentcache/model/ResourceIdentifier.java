package com.scb.channels.foundation.contentcache.model;

import static com.scb.channels.foundation.util.ReflectionBuilder.builderFor;

public class ResourceIdentifier { //TODO the key logic should be in 1 place, now its in resourceSummary to

    private String applicationId;
    private String subClassification;
    private String classification;
    private String resourceId;
    private String id;

    public interface ResourceIdentifierBuilder {
        ResourceIdentifierBuilder applicationId(String applicationId);
        ResourceIdentifierBuilder classification(String classification);
        ResourceIdentifierBuilder resourceId(String resourceId);
        ResourceIdentifierBuilder subClassification(String subClassification);
        ResourceIdentifierBuilder id(String id);
        ResourceIdentifier build();
    }

    public static ResourceIdentifierBuilder builder() {
        return builderFor(ResourceIdentifierBuilder.class);
    }

    public String getClassificationResourceIdCompoundKey() {
        return applicationId + ":" + classification + ":" + resourceId;
    }

    public String getSubClassificationClassificationCompoundKey() {
        return applicationId + ":" + subClassification +":" + classification ;
    }

    public String getClassificationCompoundKey() {
        return applicationId + ":" + classification;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getClassification() {
        return classification;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getSubClassification() {
        return subClassification;
    }

    public String getId() {
        return getApplicationId()  + ":" + getSubClassification() + ":" + getClassification() + ":" +getResourceId();
    }
}
