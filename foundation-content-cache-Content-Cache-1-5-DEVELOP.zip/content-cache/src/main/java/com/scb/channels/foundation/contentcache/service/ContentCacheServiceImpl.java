package com.scb.channels.foundation.contentcache.service;

import com.scb.channels.foundation.api.dto.contentcache.ResourceFilter;
import com.scb.channels.foundation.contentcache.api.dto.ResourceLinks;
import com.scb.channels.foundation.contentcache.api.resource.ContentCacheContext;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.ResourceRepository;
import com.scb.channels.foundation.entitlement.dap.DapPolicy;
import com.scb.channels.foundation.entitlement.dap.DapPolicyFactory;
import com.scb.channels.foundation.entitlement.dap.impl.AnnotationBasedDapPolicyFactory;
import com.scb.channels.foundation.entitlement.dap.impl.CompositeDapPolicyFactory;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MediaType;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ContentCacheServiceImpl implements ContentCacheService {

    private static final Logger LOG = LoggerFactory.getLogger(ContentCacheServiceImpl.class);

    private DapPolicyFactory dapPolicyFactory;

    private ResourceRepository resourceRepository;

    private String dap;

    @Autowired
    public ContentCacheServiceImpl(ResourceRepository resourceRepository, @Value("${suppress.dap.plugin}") String dap) {
        this.resourceRepository = resourceRepository;
        this.dap = dap;

        StaticDapPolicyFactory.init(new CompositeDapPolicyFactory(
                new AnnotationBasedDapPolicyFactory(), new CompositeDapPolicyFactory()));
        dapPolicyFactory = StaticDapPolicyFactory.INSTANCE;
    }


    @Override
    public Collection<ResourceEntity> resourceByClassification(String applicationId, String classification, ContentCacheContext contentCacheContext) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .applicationId(applicationId)
                .classification(classification)
                .build();
        LOG.info("Loading resource for [{}]", identifier.getClassificationCompoundKey());
        Collection<ResourceSummary> summaries = resourceRepository.loadSummaryByClassification(identifier);
        Collection<ResourceEntity> resourceEntities = resourceRepository.loadResourcesById(summaries.stream().map(ResourceSummary::getId)
                .collect(Collectors.toList()), MediaType.APPLICATION_JSON);
        return resourceEntities.stream().filter(r -> access(r.getResourceSummary(), contentCacheContext)).collect(Collectors.toList());
    }

    @Override
    public ResourceEntity compositeResourceByClassification(String applicationId, String classification, ContentCacheContext contentCacheContext) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .applicationId(applicationId)
                .classification(classification)
                .subClassification(null)
                .resourceId("0")
                .build();
        LOG.info("Loading resource for [{}]", identifier.getId());
        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId(), MediaType.APPLICATION_JSON);
        return access(resourceEntity.getResourceSummary(), contentCacheContext) ? resourceEntity:null;
    }


    @Override
    public ResourceEntity resourceByClassificationAndResourceId(String applicationId, String classification, String resourceId, ContentCacheContext contentCacheContext) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .applicationId(applicationId)
                .classification(classification)
                .resourceId(resourceId)
                .build();
        LOG.info("Loading resource for [{}] ", identifier.getClassificationResourceIdCompoundKey());
        Collection<ResourceSummary> summaries = resourceRepository.loadSummaryByClassificationAndResourceId(identifier);
        if(summaries.size() != 0) {
            ResourceEntity resourceEntity = resourceRepository.loadResourceById(summaries.stream().findFirst().get().getId(), MediaType.APPLICATION_JSON);
            return (access(resourceEntity.getResourceSummary(), contentCacheContext)) ? resourceEntity : null;
        }
        return null;
    }


    @Override
    public ResourceEntity resourceById(String applicationId, String subClassification, String classification, String resourceId, ContentCacheContext contentCacheContext) {
       ResourceIdentifier identifier = ResourceIdentifier.builder()
               .applicationId(applicationId)
               .classification(classification)
               .subClassification(subClassification)
               .resourceId(resourceId)
               .build();
        LOG.info("Loading resource for [{}]", identifier.getId());
        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId());
        return access(resourceEntity.getResourceSummary(), contentCacheContext) ? resourceEntity : null;
    }


    @Override
    public ResourceEntity resourceByResourceId(String applicationId, String resourceId, ContentCacheContext contentCacheContext) {
        LOG.info("Loading resource for [{}] ", resourceId);
        ResourceEntity resourceEntity = resourceRepository.loadResourceByResourceId(resourceId);
        return access(resourceEntity.getResourceSummary(), contentCacheContext) ? resourceEntity : null;
    }


    @Override
    public Collection<ResourceEntity> resourceBySubClassificationAndClassification(String applicationId, String subClassification, String classification, ContentCacheContext contentCacheContext) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .applicationId(applicationId)
                .classification(classification)
                .subClassification(subClassification)
                .build();
        LOG.info("Loading resource for [{}] ", identifier.getSubClassificationClassificationCompoundKey());
        Collection<ResourceSummary> summaries = resourceRepository.loadSummaryBySubClassificationAndClassification(identifier);
        Collection<ResourceEntity> resourceEntities = resourceRepository.loadResourcesById(summaries.stream().map(s -> s.getId())
                .collect(Collectors.toList()), MediaType.APPLICATION_JSON);
        return resourceEntities.stream().filter(r -> access(r.getResourceSummary(), contentCacheContext)).collect(Collectors.toList());
    }


    @Override
    public ResourceLinks resourceLinksByClassification(String applicationId, String classification) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .applicationId(applicationId)
                .classification(classification)
                .build();
        Collection<ResourceSummary> summaries = resourceRepository.loadSummaryByClassification(identifier);
        return ResourceLinks.from(summaries);
    }


    @Override
    public Collection<ResourceEntity> resourceByIds(ResourceFilter resourceRequest, ContentCacheContext contentCacheContext) {
        List<String> ids = resourceRequest.getResourceId().stream().map(resourceId -> ResourceIdentifier.builder()
                .applicationId(resourceRequest.getApplicationId())
                .subClassification(resourceRequest.getSubClassification())
                .classification(resourceRequest.getClassification())
                .resourceId(resourceId)
                .build().getId())
                .collect(Collectors.toList());
        Collection<ResourceEntity> resourceEntities = resourceRepository.loadResourcesById(ids);
        return  resourceEntities.stream().filter(r -> access(r.getResourceSummary(), contentCacheContext)).collect(Collectors.toList());
    }


    @Override
    public Collection<ResourceEntity> resourceByResourceIds(ResourceFilter resourceRequest, ContentCacheContext contentCacheContext) {
        Collection<ResourceEntity> resourceEntities = resourceRepository.loadResourceByResourceIds(resourceRequest.getResourceId());
        return  resourceEntities.stream().filter(r -> access(r.getResourceSummary(), contentCacheContext)).collect(Collectors.toList());
    }


    @Override
    public void persistResource(ResourceEntity resourceEntity) {
        resourceRepository.persistResource(resourceEntity);
    }


    @Override
    public Map<String, ResourceSummary> resourceSummariesByClassificationAndResourceId(List<ResourceIdentifier> identifier, ContentCacheContext contentCacheContext) {
        Collection<Collection<ResourceSummary>> resourceSummary = resourceRepository.loadSummaryListByClsAndResourceId(identifier);
        Map<String, ResourceSummary> summaryMap = new HashMap<>();
        List<ResourceSummary> summaryList = resourceSummary.stream().flatMap(Collection::stream).collect(Collectors.toList());
        summaryList.forEach(s -> summaryMap.put(s.getResourceId(), s));
        Map<String, ResourceSummary> summary = summaryMap.entrySet().stream().filter(m -> access(m.getValue(), contentCacheContext)).collect(Collectors.toMap(r -> r.getKey(), r -> r.getValue()));
        return summary;
    }


    private boolean access(ResourceSummary summary, ContentCacheContext contentCacheContext) {
        if(summary == null) return false;

        if(!Boolean.valueOf(dap)) {
            if(summary.getDapTopic().length == 0)  {
                LOG.info("Access granted, No dappolicy found for document "+summary.getId());
                return true;
            }

            if(StringUtils.isBlank(contentCacheContext.getUserId())) return false;

            LOG.info("Dap check started for userId "+contentCacheContext.getUserId());
            long start = System.currentTimeMillis();
            DapPolicy dapPolicy = getDapPolicy(contentCacheContext);
            if(dapPolicy == null) {
                LOG.info("Dap policy not found for request from user id "+contentCacheContext.getUserId());
                return false;
            }
            boolean access = dapPolicy.hasAccess(contentCacheContext.getUserId(), summary.getClassification(), summary.getDapTopic());
            LOG.info("Dap check completed for userId "+contentCacheContext.getUserId()+" in " + (System.currentTimeMillis() - start) + " ms. ");
            return access;
        } else {
            return true;
        }
    }

    private DapPolicy getDapPolicy(ContentCacheContext contentCacheContext) {
        LOG.info("Dappolicy in request header "+contentCacheContext.getDapPolicy());
        return (StringUtils.isBlank(contentCacheContext.getDapPolicy())) ? null : dapPolicyFactory.create(contentCacheContext.getDapPolicy());
    }
}
