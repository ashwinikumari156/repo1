package com.scb.channels.foundation.contentcache.api.dto;

import com.scb.channels.foundation.contentcache.model.ResourceSummary;

import java.util.Collection;
import java.util.List;

import static java.util.stream.Collectors.toList;

public class ResourceLinks {

    private List<ResourceLink> links;

    public ResourceLinks(List<ResourceLink> links) {
        this.links = links;
    }

    public List<ResourceLink> getLinks() {
        return links;
    }

    public static ResourceLinks from(Collection<ResourceSummary> resources) {
        return new ResourceLinks(resources.stream().map(r -> ResourceLink.from(r)).collect(toList()));
    }
}
