package com.scb.channels.foundation.contentcache.model;


import com.google.common.collect.Lists;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.output.ByteArrayOutputStream;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class ResourceEntity {

    private ResourceSummary resourceSummary;
    private byte[] content;

    public ResourceEntity(ResourceSummary resourceSummary, InputStream content) {
        this.resourceSummary = resourceSummary;
        try {
            this.content = IOUtils.toByteArray(content);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
    }

    public Stream<ResourceFragment> chunk(int maxChunkSize) {
        try {
            List<ResourceFragment> results = Lists.newArrayList();
            InputStream content = this.getContent();
            int read;
            int fragmentIndex = 0;
            int bufferSize;
            byte[] buffer = null;
            while (content.available() > 0) {
                if (content.available() > maxChunkSize) {
                    bufferSize = maxChunkSize;
                } else {
                    bufferSize = content.available();
                }
                buffer = new byte[bufferSize];
                read = content.read(buffer, 0, bufferSize);
                results.add(new ResourceFragment(this.resourceSummary, new ByteArrayInputStream(buffer), fragmentIndex++, read < maxChunkSize));
            }        return results.stream();
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);    }
    }

    public ByteBuffer getContentAsByteBuffer() {
        return ByteBuffer.wrap(content);
    }

    public static ResourceEntity fromFragments(List<ResourceFragment> fragments) {
        if (fragments.isEmpty())
            return null;
        List<ResourceFragment> frags = Lists.newArrayList(fragments);
        Collections.sort(frags, (fragment, t1) -> Integer.compare(fragment.getFragmentIndex(), t1.getFragmentIndex()));
        ResourceFragment root = fragments.get(0);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        frags.forEach(frag -> write(output,frag.getContentAsByteBuffer().array()));
        return new ResourceEntity(root.getResourceSummary(), new ByteArrayInputStream(output.toByteArray()));
    }

    private static void write(OutputStream output, byte[] array) {
        try {
            output.write(array);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
    }

    public int getContentSize() {
        return content.length;
    }

    public ResourceSummary getResourceSummary() {
        return resourceSummary;
    }

    public InputStream getContent() {
        return new ByteArrayInputStream(content);
    }


}