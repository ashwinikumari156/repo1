package com.scb.channels.foundation.contentcache.api.resource;

import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.core.HttpHeaders;
import javax.xml.bind.DatatypeConverter;
import java.util.Map;

public class ContentCacheContext {

    private Map<String,String> httpHeaders = Maps.newConcurrentMap();

    @Autowired
    public ContentCacheContext(Map<String,String> httpHeaders) {
        this.httpHeaders.putAll(httpHeaders);
    }

    public ContentCacheContext(String userId, String dapPolicy) {
        this.httpHeaders.put("userid",userId);
        this.httpHeaders.put("dappolicy",dapPolicy);
    }

    public String getUserId() {
        String userId = httpHeaders.get("userid");
        if (userId == null) {
            String authHeader = httpHeaders.get(HttpHeaders.AUTHORIZATION.toLowerCase());
            if (authHeader == null) {
                throw new IllegalArgumentException("UserId header is not specified, this mandatory header must be present for each request.");
            }
            userId = new String(DatatypeConverter.parseBase64Binary(authHeader.substring("Basic ".length()))).split(":")[0];
        }
        return userId;
    }

    public String getDapPolicy() {
        String dappolicy = httpHeaders.get("dappolicy");
        return dappolicy == null ? "Research" : dappolicy;
    }
}
