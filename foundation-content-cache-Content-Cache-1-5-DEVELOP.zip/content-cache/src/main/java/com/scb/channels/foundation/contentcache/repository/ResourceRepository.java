package com.scb.channels.foundation.contentcache.repository;

import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceFragment;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;

import java.util.Collection;
import java.util.List;


public interface ResourceRepository extends Repository {

    void persistFragment(ResourceFragment... resourceFragment);
    void persistResource(ResourceEntity resourceEntity);

    ResourceEntity loadResourceById(String id);
    ResourceEntity loadResourceByResourceId(String id);

    Collection<ResourceEntity> loadResourcesById(List<String> ids, String contentType);
    Collection<ResourceEntity> loadResourcesById(List<String> ids);
    Collection<ResourceEntity> loadResourceByResourceIds(List<String> ids);


    ResourceEntity loadResourceById(String id, String contentType);

    Collection<ResourceSummary> loadSummaryByClassification(ResourceIdentifier identifier);
    Collection<ResourceSummary> loadSummaryByClassificationAndResourceId(ResourceIdentifier identifier);
    Collection<ResourceSummary> loadSummaryBySubClassificationAndClassification(ResourceIdentifier identifier);

    List<ResourceFragment> loadFragmentsById(String id);

    Collection<Collection<ResourceSummary>> loadSummaryListByClsAndResourceId(List<ResourceIdentifier> identifier);
}
