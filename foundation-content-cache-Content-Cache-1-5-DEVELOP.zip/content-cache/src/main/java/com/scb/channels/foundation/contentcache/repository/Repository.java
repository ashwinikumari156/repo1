package com.scb.channels.foundation.contentcache.repository;

import com.scb.channels.persistence.PersistableBatchBuilder;

public interface Repository {
    PersistableBatchBuilder newBatch();
}
