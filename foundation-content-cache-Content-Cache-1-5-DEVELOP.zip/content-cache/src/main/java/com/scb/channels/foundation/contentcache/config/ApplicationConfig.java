package com.scb.channels.foundation.contentcache.config;

import com.scb.channels.foundation.util.jackson.JacksonMarshaller;
import com.scb.channels.foundation.util.jackson.Marshaller;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {

    @Bean
    public Marshaller marshaller() {
        return new JacksonMarshaller();
    }

}
