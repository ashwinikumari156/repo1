package com.scb.channels.foundation.contentcache.consumer;

import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceFragment;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.ResourceRepository;
import com.scb.channels.foundation.models.Message;
import com.scb.channels.foundation.util.jackson.Marshaller;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.util.List;

@Component
public class MessageHandlerImpl implements MessageHandler {

    private static final String DELETE_ACTION = "delete";
    private static final Logger logger = LoggerFactory.getLogger(MessageHandlerImpl.class);

    Marshaller marshaller;

    private ResourceRepository resourceRepository;

    @Autowired
    public MessageHandlerImpl(ResourceRepository resourceRepository, Marshaller marshaller) {
        this.resourceRepository = resourceRepository;
        this.marshaller = marshaller;
    }

    @Override
    public void processMessage(String message) {
        Message receivedMsg = marshaller.unmarshalLenient(message, Message.class);
        logger.info("{}: Processing message", receivedMsg.getHeader().getMessageID());
        try {
            if(receivedMsg.getHeader().getAction().equalsIgnoreCase("delete")) {
                markResourceAsDeleted(receivedMsg);
                return;
            }
            persistResource(receivedMsg);
        } catch (IOException e) {
            logger.error("Error persisting message: " + e.getMessage(),e);
            //TODO: push exception to DLQ
        }
        logger.info("{}: Finished processing message", receivedMsg.getHeader().getMessageID());
    }


    private void markResourceAsDeleted(Message receivedMsg) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .classification(receivedMsg.getHeader().getCategory())
                .subClassification(StringUtils.isBlank(receivedMsg.getHeader().getSubCategory()) ? "null" : receivedMsg.getHeader().getSubCategory())
                .applicationId(receivedMsg.getHeader().getApplicationId())
                .resourceId(receivedMsg.getHeader().getDocumentId())
                .build();
        List<ResourceFragment> resourceFragments = resourceRepository.loadFragmentsById(identifier.getId());

        ResourceFragment[] resourceFragmentsToDelete = new ResourceFragment[resourceFragments.size()];

        for(int i=0; i<resourceFragments.size(); i++) {
            resourceFragmentsToDelete[i] = resourceFragmentToDelete(resourceFragments.get(i));
        }
        resourceRepository.persistFragment(resourceFragmentsToDelete);
    }


    private void persistResource(Message receivedMsg) throws IOException {
        byte[] data = dataFromMessage(receivedMsg);
        ResourceSummary summary = resourceSummary(receivedMsg, data);
        if (receivedMsg.getHeader().isFragment()) {
            resourceRepository.persistFragment(new ResourceFragment(summary,
                    new ByteArrayInputStream(data),
                    receivedMsg.getHeader().getFragmentIndex(),
                    receivedMsg.getHeader().isFinalFragment()));
        } else {
            resourceRepository.persistResource(new ResourceEntity(summary, new ByteArrayInputStream(data)));
        }
    }

    private byte[] dataFromMessage(Message receivedMsg) throws IOException {
        Pair<InputStream,String> content = Pair.of(receivedMsg.getContentDescriptor().getRawContent(), receivedMsg.getContentDescriptor().getContentType());
        try(InputStream stream = content.getKey()) {
            return IOUtils.toByteArray(stream);
        }
    }

    private ResourceSummary resourceSummary(Message receivedMsg, byte[] data) throws IOException {

        return ResourceSummary.builder()
                .applicationId(receivedMsg.getHeader().getApplicationId())
                .subClassification(receivedMsg.getHeader().getSubCategory())
                .classification(receivedMsg.getHeader().getCategory())
                .resourceId(receivedMsg.getHeader().getDocumentId())
                .contentType(receivedMsg.getContentDescriptor().getContentType())
                .createdAt(Instant.now())
                .dapTopic(receivedMsg.getHeader().getDapTopic())
                .receivedAt(receivedMsg.getHeader().getMessageTimestamp())
                .size(data.length)
                .md5hash(receivedMsg.getHeader().getMd5hash())
                .build();

    }

    private ResourceFragment resourceFragmentToDelete(ResourceFragment fragment) {
        ResourceSummary summary = ResourceSummary.builder()
                .contentType(fragment.getResourceSummary().getContentType())
                .classification(fragment.getResourceSummary().getClassification())
                .subClassification(fragment.getResourceSummary().getSubClassification())
                .applicationId(fragment.getResourceSummary().getApplicationId())
                .createdAt(fragment.getResourceSummary().getCreatedAt())
                .receivedAt(fragment.getResourceSummary().getReceivedAt())
                .dapTopic(fragment.getResourceSummary().getDapTopic())
                .size(fragment.getResourceSummary().getSize())
                .md5hash(fragment.getResourceSummary().getMd5hash())
                .deleted(true)
                .resourceId(fragment.getResourceSummary().getResourceId())
                .id(fragment.getResourceSummary().getId())
                .build();

        return new ResourceFragment(summary, fragment.getContent(), fragment.getFragmentIndex(), fragment.isLast());
    }


}
