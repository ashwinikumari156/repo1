package com.scb.channels.foundation.contentcache.api.dto;

public class ReadershipAnalytics {

    private String resourceId;
    private String formattedResourceId;
    private Integer readCount;

    public ReadershipAnalytics(String resourceId, String formattedResourceId, Integer readCount) {
        this.resourceId = resourceId;
        this.formattedResourceId = formattedResourceId;
        this.readCount = readCount;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getFormattedResourceId() {
        return formattedResourceId;
    }

    public Integer getReadCount() {
        return readCount;
    }
}
