package com.scb.channels.foundation.contentcache.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

public class ContentListener {
    private static final Logger LOG = LoggerFactory.getLogger(ContentListener.class);

    @Autowired
    private MessageHandler messageHandler;

    @KafkaListener(topics = "${services.topics}")
    public void onMessage(String message) {
        try {
            messageHandler.processMessage(message);
        } catch (Exception e){
            LOG.error("Error in processing message {} - {}", message, e);
        }
    }

}
