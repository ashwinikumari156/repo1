package com.scb.channels.foundation.contentcache.api.resource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Sets;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderRequest;
import com.scb.channels.foundation.api.dto.recon.ReconHeaderResponse;
import com.scb.channels.foundation.api.dto.recon.ReconHeaders;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.ResourceRepository;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.Path;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Path("/recon")
public class ReconResourceImpl implements ReconResource {

    private Logger logger = LoggerFactory.getLogger(ReconResourceImpl.class);
    private ResourceRepository resourceRepository;
    private ContentCacheContext contentCacheContext;

    @Autowired
    public ReconResourceImpl(ResourceRepository resourceRepository, ContentCacheContext contentCacheContext) {
        this.resourceRepository = resourceRepository;
        this.contentCacheContext = contentCacheContext;
    }

    public ReconHeaderResponse resolveReconHeaders(ReconHeaderRequest request) throws JsonProcessingException {

        List<ReconHeaders> headersToAddOrUpdate = new ArrayList<>();
        Set<String> reconIds = new HashSet<>();
        Set<String> idsInDb = new HashSet<>();
        Map<String, ResourceSummary> resourceEntityMap = new HashMap<>();
        ReconHeaders initialHeader = request.getFirstHeader();

        Collection<ResourceSummary> fullList = loadResourceJsonByClsAndSubCls(initialHeader.getApplicationId(), initialHeader.getEntityType(), initialHeader.getSubCategory());

        for(ResourceSummary summary : fullList) {
            resourceEntityMap.put(summary.getResourceId(), summary);
            idsInDb.add(summary.getResourceId());
        }

        for(ReconHeaders recon : request.getReconHeaders()) {
            reconIds.add(recon.getIdentifiers().get(0));
            ResourceSummary summary = resourceEntityMap.get(recon.getIdentifiers().get(0));
            if(summary == null) {
                headersToAddOrUpdate.add(recon);
            } else {
                boolean after = Instant.ofEpochSecond(recon.getTimestamp()).isAfter(summary.getReceivedAt());
                if (after) {
                    headersToAddOrUpdate.add(recon);
                }
            }
        }

        List<ReconHeaders> resourceToDeactivate = getResourceToDeactivate(reconIds, idsInDb, resourceEntityMap);
        ReconHeaderResponse response = new ReconHeaderResponse(headersToAddOrUpdate, resourceToDeactivate);
        return response;
    }

    private List<ReconHeaders> getResourceToDeactivate(Set<String> reconIds, Set<String> idsInDb, Map<String, ResourceSummary> resourceEntityMap) {
       List<ReconHeaders> headersToDeactivate = new ArrayList<>();
        Sets.SetView<String> idsToDeactivate = Sets.difference(idsInDb, reconIds);
        idsToDeactivate.stream().forEach(r -> {
            ResourceSummary summary = resourceEntityMap.get(r);
            ReconHeaders reconHeaders = ReconHeaders.builder()
                    .identifiers(ImmutableList.of(summary.getResourceId()))
                    .timestamp(summary.getReceivedAt().getEpochSecond())
                    .entityType(summary.getClassification())
                    .subCategory(summary.getSubClassification())
                    .applicationId(summary.getApplicationId())
                    .build();
            headersToDeactivate.add(reconHeaders);
        });
        return headersToDeactivate;
    }


    private Collection<ResourceSummary> loadResourceJsonByClsAndSubCls(String applicationId, String classification, String subClassification) {
        ResourceIdentifier identifier = ResourceIdentifier.builder()
                .classification(classification)
                .subClassification(StringUtils.isEmpty(subClassification) ? "null" : subClassification)
                .applicationId(applicationId)
                .build();
        Collection<ResourceSummary> resourceSummaries = resourceRepository.loadSummaryBySubClassificationAndClassification(identifier);
        return resourceSummaries.stream().filter(r -> r.getContentType().equalsIgnoreCase("application/json")).collect(Collectors.toList());
    }

}
