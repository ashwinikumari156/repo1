package com.scb.channels.foundation.contentcache.model;

import com.scb.channels.foundation.util.ReflectionBuilder;
import org.apache.commons.lang3.StringUtils;

import java.time.Instant;

public class ResourceSummary {

    private String id;
    private String resourceId;
    private String classification;
    private String subClassification;
    private String applicationId;
    private String contentType;
    private Instant createdAt;
    private Instant receivedAt;
    private String[] dapTopic;
    private int size;
    private String md5hash;
    private Boolean deleted;

    public interface ResourceSummaryBuilder {
        ResourceSummaryBuilder id(String id);
        ResourceSummaryBuilder resourceId(String resourceId);
        ResourceSummaryBuilder classification(String classification);
        ResourceSummaryBuilder subClassification(String subClassification);
        ResourceSummaryBuilder applicationId(String applicationId);
        ResourceSummaryBuilder contentType(String contentType);
        ResourceSummaryBuilder createdAt(Instant createdAt);
        ResourceSummaryBuilder receivedAt(Instant receivedAt);
        ResourceSummaryBuilder size (int size);
        ResourceSummaryBuilder dapTopic (String[] dapTopic);
        ResourceSummaryBuilder md5hash(String md5hash);
        ResourceSummaryBuilder deleted(Boolean deleted);
        ResourceSummary build();
    }

    public static ResourceSummaryBuilder builder() {
        return ReflectionBuilder.builderFor(ResourceSummaryBuilder.class);
    }

    public String getSubClassification() {
        return StringUtils.isEmpty(subClassification) ? "null" : subClassification;
    }

    public String getResourceId() {
        if(StringUtils.isEmpty(resourceId))
            return "0";
        return resourceId.charAt(0) == '/' ? resourceId.substring(1) : resourceId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getContentType() {
        return contentType;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Instant getReceivedAt() {
        return receivedAt;
    }

    public int getSize() {
        return size;
    }

    public String getClassification() {
        return classification;
    }

    public String[] getDapTopic() {
        return dapTopic;
    }

    public String getResourceCompoundKey() {
        return getApplicationId() + ":" + getClassification() + ":" + getResourceId();
    }

    public String getClsSubClsCompoundKey() {
        return getApplicationId()  + ":" + getSubClassification() + ":" + getClassification(); }

    public String getClsCompoundKey() {
        return getApplicationId()+ ":" +getClassification();
    }

    public String getId() {
        return getApplicationId()  + ":" + getSubClassification() + ":" + getClassification() + ":" +getResourceId();
    }

    public String getMd5hash() { return md5hash; }

    public Boolean getDeleted() { return deleted; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ResourceSummary summary = (ResourceSummary) o;

        if (resourceId != null ? !resourceId.equals(summary.resourceId) : summary.resourceId != null) return false;
        if (classification != null ? !classification.equals(summary.classification) : summary.classification != null)
            return false;
        if (applicationId != null ? !applicationId.equals(summary.applicationId) : summary.applicationId != null)
            return false;
        return contentType != null ? contentType.equals(summary.contentType) : summary.contentType == null;

    }

    @Override
    public int hashCode() {
        int result = resourceId != null ? resourceId.hashCode() : 0;
        result = 31 * result + (classification != null ? classification.hashCode() : 0);
        result = 31 * result + (applicationId != null ? applicationId.hashCode() : 0);
        result = 31 * result + (contentType != null ? contentType.hashCode() : 0);
        return result;
    }
}
