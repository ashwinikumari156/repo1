package com.scb.channels.foundation.contentcache;

import com.scb.channels.foundation.contentcache.api.resource.ContentCacheContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.UrlResource;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;

import static com.scb.channels.foundation.entitlement.dap.policy.research.ResearchDapPolicy.RESEARCH_CSL_ENDPOINT_CONFIG_KEY;
import static com.scb.channels.foundation.util.Http.getHeadersInfo;

@SpringBootApplication
@EnableConfigurationProperties
public class ContentCacheApplication extends SpringBootServletInitializer {

    @Value("${"+RESEARCH_CSL_ENDPOINT_CONFIG_KEY+"}")
    private String entitlementEndpoint;

    @PostConstruct
    public void setProperty() {
        System.setProperty(RESEARCH_CSL_ENDPOINT_CONFIG_KEY, entitlementEndpoint);
    }

	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() throws MalformedURLException {
		PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
		YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean();
		if (null != System.getProperty("contentcache-config")) {
			yaml.setResources(new UrlResource("file:" + System.getProperty("contentcache-config")));
		} else {
			yaml.setResources(new ClassPathResource("contentcache.yml"));
		}
		propertySourcesPlaceholderConfigurer.setProperties(yaml.getObject());
		return propertySourcesPlaceholderConfigurer;
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(ContentCacheApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ContentCacheApplication.class, args);
	}

	@Bean
	@Scope(WebApplicationContext.SCOPE_REQUEST)
	public ContentCacheContext contentCacheContext(HttpServletRequest request) {
		return new ContentCacheContext(getHeadersInfo(request));
	}
}
