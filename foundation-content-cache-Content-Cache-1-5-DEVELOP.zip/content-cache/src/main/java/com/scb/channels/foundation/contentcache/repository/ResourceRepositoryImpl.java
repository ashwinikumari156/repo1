package com.scb.channels.foundation.contentcache.repository;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceFragment;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.util.ContentCacheConstants;
import com.scb.channels.persistence.*;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.scb.channels.foundation.util.DateUtils.toTimestamp;
import static com.scb.channels.persistence.PersistableColumn.column;

@Component
public class ResourceRepositoryImpl extends AbstractRepository implements ResourceRepository, ContentCacheConstants {

    private PersistenceService persistenceService;

    public ResourceRepositoryImpl(PersistenceService persistenceService) {
        this.persistenceService = persistenceService;
    }

    @Override
    public PersistenceService persistenceService() {
        return persistenceService;
    }


    /**
     * Load data from table
     */
    @Override
    public ResourceEntity loadResourceById(String id) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>builder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ImmutableMap.of(
                                COLUMN_RESOURCE_ID, id
                        ))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }

    @Override
    public ResourceEntity loadResourceByResourceId(String id) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>builder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ImmutableMap.of(
                                COLUMN_RESOURCE_RESID, id
                        ))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }


    @Override
    public Collection<ResourceEntity> loadResourcesById(List<String> ids, String contentType) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>bulkBuilder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ids.stream().map(id -> ImmutableMap.of(COLUMN_RESOURCE_ID, id,
                                COLUMN_CONTENT_TYPE, contentType)).collect(Collectors.toList()))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }

    @Override
    public Collection<ResourceEntity> loadResourcesById(List<String> ids) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>bulkBuilder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ids.stream().map(id -> ImmutableMap.of(COLUMN_RESOURCE_ID, id)).collect(Collectors.toList()))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }

    @Override
    public Collection<ResourceEntity> loadResourceByResourceIds(List<String> ids) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>bulkBuilder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ids.stream().map(id -> ImmutableMap.of(COLUMN_RESOURCE_RESID, id)).collect(Collectors.toList()))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }


    @Override
    public ResourceEntity loadResourceById(String id, String contentType) {
        return persistenceService.retrieve(
                Loadables.<ResourceEntity>builder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ImmutableMap.of(
                                COLUMN_RESOURCE_ID, id,
                                COLUMN_CONTENT_TYPE, contentType
                        ))
                        .unmarshallingStrategy(this::resourceFromRows)
                        .build());
    }

    @Override
    public List<ResourceFragment> loadFragmentsById(String id) {
        return persistenceService.retrieve(
                Loadables.<List<ResourceFragment>>builder()
                        .targetTable(TABLE_RESOURCE_BY_ID)
                        .keyValues(ImmutableMap.of(COLUMN_RESOURCE_ID, id))
                        .unmarshallingStrategy(this::resourceFragmentFromRows)
                        .build()
        );
    }

    /**
     * Loading data from view
     */
    @Override
    public Collection<ResourceSummary> loadSummaryByClassification(ResourceIdentifier identifier) {
        return persistenceService.retrieve(
                Loadables.<Collection<ResourceSummary>>builder()
                        .targetTable(VIEW_RESOURCE_BY_CLS)
                        .keyValues(ImmutableMap.of(
                                COLUMN_COMPOUND_CLS, identifier.getClassificationCompoundKey()
                        ))
                        .unmarshallingStrategy(this::resourceSummaryFromRows)
                        .build());
    }

    @Override
    public Collection<ResourceSummary> loadSummaryByClassificationAndResourceId(ResourceIdentifier identifier) {
        return persistenceService.retrieve(
                Loadables.<Collection<ResourceSummary>>builder()
                        .targetTable(VIEW_RESOURCE_BY_CLS_RESID)
                        .keyValues(ImmutableMap.of(
                                COLUMN_COMPOUND_CLS_RESID, identifier.getClassificationResourceIdCompoundKey()
                        ))
                        .unmarshallingStrategy(this::resourceSummaryFromRows)
                        .build());
    }

    @Override
    public Collection<ResourceSummary> loadSummaryBySubClassificationAndClassification(ResourceIdentifier identifier) {
        return persistenceService.retrieve(
                Loadables.<Collection<ResourceSummary>>builder()
                        .targetTable(VIEW_RESOURCE_BY_SUBCLS)
                        .keyValues(ImmutableMap.of(
                                COLUMN_COMPOUND_CLS_SUBCLS, identifier.getSubClassificationClassificationCompoundKey()
                        ))
                        .unmarshallingStrategy(this::resourceSummaryFromRows)
                        .build());
    }


    @Override
    public Collection<Collection<ResourceSummary>> loadSummaryListByClsAndResourceId(List<ResourceIdentifier> identifiers) {
        return persistenceService.retrieve(
                Loadables.<Collection<ResourceSummary>>bulkBuilder()
                        .targetTable(VIEW_RESOURCE_BY_CLS_RESID)
                        .keyValues(identifiers.stream().map(r -> ImmutableMap.of(
                                COLUMN_COMPOUND_CLS_RESID, r.getClassificationResourceIdCompoundKey()
                        )).collect(Collectors.toList()))
                        .unmarshallingStrategy(this::resourceSummaryFromRows)
                        .build());
    }


    /**
     * Persist data
     */

    @Override
    public void persistFragment(ResourceFragment... resourceFragment) {
        PersistableBatchBuilder persistableBatchBuilder = newBatch();
        Stream.of(resourceFragment).forEach(frag -> persistableBatchBuilder.add(persistableFor(frag)));
        persistableBatchBuilder.execute();
    }

    /**
     * If resource size is greater than max_chunk_size, split the resource content and persist
     * If resource size is less than max_chunk_size, persist resource without splitting
     *
     * @param resourceEntity
     */
    @Override
    public void persistResource(ResourceEntity resourceEntity) {
        if (resourceEntity.getResourceSummary().getSize() <= MAX_CHUNK_SIZE) {
            persist(resourceEntity);
        } else {
            persistFragment(resourceEntity.chunk(MAX_CHUNK_SIZE).toArray(ResourceFragment[]::new));
        }
    }

    private void persist(ResourceEntity resourceEntity) {
        PersistableBatchBuilder persistableBatchBuilder = newBatch();
        persistableBatchBuilder.add(persistableFor(resourceEntity));
        persistableBatchBuilder.execute();
    }

    private List<Persistable<ResourceEntity>> persistableFor(ResourceEntity entity) {

        Persistable<ResourceEntity> persistableContent = Persistables.<ResourceEntity>builder()
                .object(entity)
                .targetTable(TABLE_RESOURCE_BY_ID)
                .type(Persistable.Type.Upsert)
                .keyDefinition(KeyDefinitions.singleton(COLUMN_RESOURCE_RESID, COLUMN_RESOURCE_RESID))
                .marshallingStrategy(resourceMarshallingStrategy())
                .build();

        return ImmutableList.of(persistableContent);
    }

    private List<Persistable<ResourceFragment>> persistableFor(ResourceFragment fragment) {

        Persistable<ResourceFragment> persistableContent = Persistables.<ResourceFragment>builder()
                .object(fragment)
                .targetTable(TABLE_RESOURCE_BY_ID)
                .type(Persistable.Type.Upsert)
                .keyDefinition(KeyDefinitions.singleton(COLUMN_RESOURCE_RESID, COLUMN_RESOURCE_RESID))
                .marshallingStrategy(resourceFragmentMarshallingStrategy())
                .build();

        return ImmutableList.of(persistableContent);
    }

    private MarshallingStrategy<ResourceEntity> resourceMarshallingStrategy() {
        return entity -> ImmutableList
                .<PersistableColumn>builder()
                .add(column(COLUMN_RESOURCE_RESID, entity.getResourceSummary().getResourceId()))
                .add(column(COLUMN_APPLICATION_ID, entity.getResourceSummary().getApplicationId()))
                .add(column(COLUMN_CLASSIFICATION, entity.getResourceSummary().getClassification()))
                .add(column(COLUMN_SUB_CLASSIFICATION, entity.getResourceSummary().getSubClassification()))
                .add(column(COLUMN_COMPOUND_CLS_RESID, entity.getResourceSummary().getResourceCompoundKey()))
                .add(column(COLUMN_COMPOUND_CLS_SUBCLS, entity.getResourceSummary().getClsSubClsCompoundKey()))
                .add(column(COLUMN_COMPOUND_CLS, entity.getResourceSummary().getClsCompoundKey()))
                .add(column(COLUMN_CONTENT, entity.getContentAsByteBuffer()))
                .add(column(COLUMN_CONTENT_TYPE, entity.getResourceSummary().getContentType()))
                .add(column(COLUMN_CREATED_AT, toTimestamp(entity.getResourceSummary().getCreatedAt())))
                .add(column(COLUMN_MESSAGE_TIMESTAMP, toTimestamp(entity.getResourceSummary().getReceivedAt())))
                .add(column(COLUMN_SEGMENT_SIZE, entity.getContentSize()))
                .add(column(COLUMN_RESOURCE_ID, entity.getResourceSummary().getId()))
                .add(column(COLUMN_MD5HASH, entity.getResourceSummary().getMd5hash()))
                .add(column(COLUMN_DAP_TOPIC, (entity.getResourceSummary().getDapTopic() != null) ? Arrays.asList(entity.getResourceSummary().getDapTopic()) : null))
                .add(column(COLUMN_SEGMENT_ID, 0))
                .add(column(COLUMN_DELETED, entity.getResourceSummary().getDeleted()))
                .add(column(COLUMN_IS_LAST, true))
                .build();
    }

    private MarshallingStrategy<ResourceFragment> resourceFragmentMarshallingStrategy() {
        return entity -> ImmutableList
                .<PersistableColumn>builder()
                .add(column(COLUMN_RESOURCE_RESID, entity.getResourceSummary().getResourceId()))
                .add(column(COLUMN_APPLICATION_ID, entity.getResourceSummary().getApplicationId()))
                .add(column(COLUMN_CLASSIFICATION, entity.getResourceSummary().getClassification()))
                .add(column(COLUMN_SUB_CLASSIFICATION, entity.getResourceSummary().getSubClassification()))
                .add(column(COLUMN_COMPOUND_CLS_RESID, entity.getResourceSummary().getResourceCompoundKey()))
                .add(column(COLUMN_COMPOUND_CLS_SUBCLS, entity.getResourceSummary().getClsSubClsCompoundKey()))
                .add(column(COLUMN_COMPOUND_CLS, entity.getResourceSummary().getClsCompoundKey()))
                .add(column(COLUMN_CONTENT, entity.getContentAsByteBuffer()))
                .add(column(COLUMN_CONTENT_TYPE, entity.getResourceSummary().getContentType()))
                .add(column(COLUMN_CREATED_AT, toTimestamp(entity.getResourceSummary().getCreatedAt())))
                .add(column(COLUMN_MESSAGE_TIMESTAMP, toTimestamp(entity.getResourceSummary().getReceivedAt())))
                .add(column(COLUMN_SEGMENT_ID, entity.getFragmentIndex()))
                .add(column(COLUMN_SEGMENT_SIZE, entity.getFragmentSize()))
                .add(column(COLUMN_RESOURCE_ID, entity.getResourceSummary().getId()))
                .add(column(COLUMN_MD5HASH, entity.getResourceSummary().getMd5hash()))
                .add(column(COLUMN_DAP_TOPIC, (entity.getResourceSummary().getDapTopic() != null) ?
                        Arrays.asList(entity.getResourceSummary().getDapTopic()) : null))
                .add(column(COLUMN_IS_LAST, entity.isLast()))
                .add(column(COLUMN_DELETED, entity.getResourceSummary().getDeleted()))
                .build();
    }

    /**
     * Fetch all resource chunks based on resourceId, reassemble and return ResourceEntity
     *
     * @param resultSet
     * @return resourceEntity
     */
    private ResourceEntity resourceFromRows(ResultSet resultSet) {

        List<ResourceFragment> fragments = Lists.newArrayList();
        int lastSegmentIndex = 0;
        boolean isComplete = false;
        for (Row row : resultSet) {
            boolean deleted = row.getBool(COLUMN_DELETED);
            if (deleted) {
                continue;
            }

            String id = row.getString(COLUMN_RESOURCE_ID);
            isComplete = row.getBool(COLUMN_IS_LAST);
            String resourceId = row.getString(COLUMN_RESOURCE_RESID);
            String applicationId = row.getString(COLUMN_APPLICATION_ID);
            String contentType = row.getString(COLUMN_CONTENT_TYPE);
            String classification = row.getString(COLUMN_CLASSIFICATION);
            String subClassification = row.getString(COLUMN_SUB_CLASSIFICATION);
            Instant timeStamp = row.getTimestamp(COLUMN_CREATED_AT).toInstant();
            String md5hash = row.getString(COLUMN_MD5HASH);
            String[] dapTopic = row.getList(COLUMN_DAP_TOPIC, String.class).stream().toArray(String[]::new);
            lastSegmentIndex = row.getInt(COLUMN_SEGMENT_ID);
            Instant receivedAt = row.getTimestamp(COLUMN_MESSAGE_TIMESTAMP).toInstant();
            byte[] bytes = row.getBytes(COLUMN_CONTENT).array();
            fragments.add(new ResourceFragment(
                    ResourceSummary.builder()
                            .applicationId(applicationId)
                            .classification(classification)
                            .subClassification(subClassification)
                            .contentType(contentType)
                            .resourceId(resourceId)
                            .receivedAt(timeStamp)
                            .dapTopic(dapTopic)
                            .createdAt(Instant.now())
                            .receivedAt(receivedAt)
                            .id(id)
                            .deleted(deleted)
                            .size(bytes.length)
                            .md5hash(md5hash)
                            .build(),
                    new ByteArrayInputStream(bytes), lastSegmentIndex, isComplete));

            if (isComplete) {
                break;
            }
        }
        return (isComplete && (fragments.size() - 1 == lastSegmentIndex))
                ? ResourceEntity.fromFragments(fragments) : ResourceEntity.fromFragments(Collections.emptyList());

    }

    private Collection<ResourceSummary> resourceSummaryFromRows(ResultSet rows) {

        Map<ResourceSummary, AtomicInteger> segmentCount = Maps.newConcurrentMap();
        Map<ResourceSummary, Integer> completionIndex = Maps.newConcurrentMap();

        for (Row row : rows) {
            boolean deleted = row.getBool(COLUMN_DELETED);
            if (deleted) {
                continue;
            }

            boolean isComplete = row.getBool(COLUMN_IS_LAST);
            String id = row.getString(COLUMN_RESOURCE_ID);
            String resourceId = row.getString(COLUMN_RESOURCE_RESID);
            String applicationId = row.getString(COLUMN_APPLICATION_ID);
            String contentType = row.getString(COLUMN_CONTENT_TYPE);
            String classification = row.getString(COLUMN_CLASSIFICATION);
            String subClassification = row.getString(COLUMN_SUB_CLASSIFICATION);
            String md5hash = row.getString(COLUMN_MD5HASH);
            int size = row.getInt(COLUMN_SEGMENT_SIZE);
            Instant timeStamp = row.getTimestamp(COLUMN_CREATED_AT).toInstant();
            Instant receivedAt = row.getTimestamp(COLUMN_MESSAGE_TIMESTAMP).toInstant();
            String[] dapTopic = row.getList(COLUMN_DAP_TOPIC, String.class).stream().toArray(String[]::new);
            int segmentIndex = row.getInt(COLUMN_SEGMENT_ID);

            ResourceSummary summary = ResourceSummary.builder()
                    .applicationId(applicationId)
                    .classification(classification)
                    .subClassification(subClassification)
                    .contentType(contentType)
                    .resourceId(resourceId)
                    .createdAt(timeStamp)
                    .receivedAt(receivedAt)
                    .id(id)
                    .size(size)
                    .md5hash(md5hash)
                    .deleted(deleted)
                    .dapTopic(dapTopic)
                    .build();

            segmentCount.putIfAbsent(summary, new AtomicInteger(0));
            segmentCount.get(summary).getAndIncrement();
            if (isComplete) {
                completionIndex.put(summary, segmentIndex);
            }
        }

        return completionIndex.entrySet().stream().filter(rs ->
                segmentCount.get(rs.getKey()).get() == (rs.getValue() + 1)).map(Map.Entry::getKey).collect(Collectors.toList());
    }


    private List<ResourceFragment> resourceFragmentFromRows(ResultSet resultSet) {
        List<ResourceFragment> resourceFragments = new ArrayList<>();
        for (Row row : resultSet) {

            boolean deleted = row.getBool(COLUMN_DELETED);

            if (deleted) {
                continue;
            }

            boolean isComplete = row.getBool(COLUMN_IS_LAST);
            String id = row.getString(COLUMN_RESOURCE_ID);
            String resourceId = row.getString(COLUMN_RESOURCE_RESID);
            String applicationId = row.getString(COLUMN_APPLICATION_ID);
            String contentType = row.getString(COLUMN_CONTENT_TYPE);
            String classification = row.getString(COLUMN_CLASSIFICATION);
            String subClassification = row.getString(COLUMN_SUB_CLASSIFICATION);
            Instant createdTime = row.getTimestamp(COLUMN_CREATED_AT).toInstant();
            Instant receivedTime = row.getTimestamp(COLUMN_MESSAGE_TIMESTAMP).toInstant();
            String md5hash = row.getString(COLUMN_MD5HASH);
            String[] dapTopic = row.getList(COLUMN_DAP_TOPIC, String.class).stream().toArray(String[]::new);
            int segmentIndex = row.getInt(COLUMN_SEGMENT_ID);
            byte[] bytes = row.getBytes(COLUMN_CONTENT).array();
            int size = row.getInt(COLUMN_SEGMENT_SIZE);

            ResourceSummary summary = ResourceSummary.builder()
                    .contentType(contentType)
                    .classification(classification)
                    .subClassification(subClassification)
                    .applicationId(applicationId)
                    .createdAt(createdTime)
                    .receivedAt(receivedTime)
                    .dapTopic(dapTopic)
                    .size(size)
                    .md5hash(md5hash)
                    .deleted(deleted)
                    .resourceId(resourceId)
                    .id(id)
                    .build();

            ResourceFragment resourceFragment = new ResourceFragment(summary, new ByteArrayInputStream(bytes), segmentIndex, isComplete);
            resourceFragments.add(resourceFragment);
        }
        return resourceFragments;

    }

}
