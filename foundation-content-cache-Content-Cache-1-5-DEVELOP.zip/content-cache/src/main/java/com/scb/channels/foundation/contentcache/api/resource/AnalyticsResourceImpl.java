package com.scb.channels.foundation.contentcache.api.resource;

import com.scb.channels.foundation.contentcache.api.dto.ReadershipAnalytics;
import com.scb.channels.foundation.contentcache.api.dto.ReadershipRawData;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.AnalyticsRepository;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import com.scb.channels.foundation.contentcache.util.ResourceUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Path("/analytics")
@Produces({MediaType.APPLICATION_JSON, "application/pdf", "application/zip"})
public class AnalyticsResourceImpl implements AnalyticsResource {

    public static final String PAYLOAD = "payload";
    public static final String PDF = ".pdf";

    private AnalyticsRepository analyticsRepository;

    private ContentCacheService contentCacheService;

    private ContentCacheContext contentCacheContext;

    @Autowired
    public AnalyticsResourceImpl(AnalyticsRepository analyticsRepository, ContentCacheService contentCacheService, ContentCacheContext contentCacheContext) {
        this.analyticsRepository = analyticsRepository;
        this.contentCacheService = contentCacheService;
        this.contentCacheContext = contentCacheContext;
    }

    @GET
    @Path("/readership/{applicationId}/{startTime}/{endTime}")
    @ApiOperation(value = "Get readership",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getReadership(@ApiParam(required = true) @PathParam("applicationId") String applicationId,@PathParam("startTime") String startDate,
                                  @PathParam("endTime") String endDate ) {
        Instant startTime;
        Instant endTime;
        validateRequestParams(applicationId, startDate, endDate);
        try {
            startTime = Instant.parse(startDate);
            endTime = Instant.parse(endDate);
        } catch (Exception e){
            throw new BadRequestException("Invalid date");
        }

        Collection<Readership> readerships = analyticsRepository.loadReadership();
        ResourceUtil.notFoundIfEmpty(readerships, "Readership not found");
        Map<String, List<ReadershipRawData>> map = new HashMap<>();

        List<ReadershipRawData> rawData = readerships.stream().map(r -> ReadershipRawData.builder()
                .userId(r.getUserId())
                .resourceId(r.getResourceId().replace(PDF, ""))
                .accessTime(r.getCreatedAt().toString())
                .id(r.getId())
                .build()).collect(Collectors.toList());


        List<ReadershipRawData> filteredrawData = rawData.stream().filter(r -> Instant.parse(r.getAccessTime()).isAfter(startTime)
                && Instant.parse(r.getAccessTime()).isBefore(endTime)).collect(Collectors.toList());
        map.put(PAYLOAD, filteredrawData);
        return Response.ok(map).build();
    }

    @GET
    @Path("/readershipForWeek/{applicationId}")
    @ApiOperation(value = "Get readership for the week",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getReadershipForTheWeek(@ApiParam(required = true) @PathParam("applicationId") String applicationId) {
        validateRequestParams(applicationId);
        Instant aWeekAgo = Instant.now().minus(Duration.ofDays(8));
        List<ReadershipAnalytics> analytics = groupByResourceAndUser(aWeekAgo, analyticsRepository.loadReadership());
        ResourceUtil.notFoundIfEmpty(analytics, "Readership not found");

        List<ReadershipAnalytics> readershipForUser = readershipForUser(analytics, applicationId);
        ResourceUtil.notFoundIfEmpty(readershipForUser, "Readership not found");

        readershipForUser.sort(Comparator.comparing(ReadershipAnalytics::getReadCount).reversed());
        Map<String, List<ReadershipAnalytics>> map = new HashMap<>();
        map.put(PAYLOAD, readershipForUser);
        return Response.ok(map).build();
    }


    private List<ReadershipAnalytics> groupByResourceAndUser(Instant startTime, Collection<Readership> readerships) {
        Map<String, AtomicInteger> reportMap = new HashMap<>();
        readerships.parallelStream()
                .filter(r -> r.getCreatedAt().isAfter(startTime))
                .collect(Collectors.toMap(r -> r.getResourceId() + "-" + r.getUserId(), Function.identity(), (r1, r2) -> r1))
                .forEach((k, v) -> {
                            reportMap.putIfAbsent(v.getResourceId(), new AtomicInteger(0));
                            reportMap.get(v.getResourceId()).getAndIncrement();
                        }
                );

        return reportMap.keySet().stream().map(k -> new ReadershipAnalytics(k, k.replace(PDF, ""), reportMap.get(k).intValue())).collect(Collectors.toList());
    }


    private List<ReadershipAnalytics> readershipForUser(List<ReadershipAnalytics> analytics, String applicationId) {
        List<ResourceIdentifier> identifiers = analytics.stream().map(i -> ResourceIdentifier.builder()
                .resourceId(i.getResourceId())
                .applicationId(applicationId)
                .classification("Report") //TODO this param should be passed from UI
                .build()).collect(Collectors.toList());

        Map<String, ResourceSummary> summaryMap = contentCacheService.resourceSummariesByClassificationAndResourceId(identifiers, contentCacheContext);
        return analytics.stream().filter(a -> (summaryMap.get(a.getResourceId()) != null)).map(a -> a).collect(Collectors.toList());
    }

    public void validateRequestParams(String... requestParams) {
        Stream.of(requestParams).forEach(d ->
                ResourceUtil.badRequestIfNull(d, String.format("Missing request params")));
    }

}
