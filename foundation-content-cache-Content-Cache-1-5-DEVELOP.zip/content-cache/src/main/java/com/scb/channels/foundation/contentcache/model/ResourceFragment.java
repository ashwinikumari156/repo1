package com.scb.channels.foundation.contentcache.model;

import org.apache.commons.io.IOUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class ResourceFragment {

    private ResourceSummary resourceSummary;
    private byte[] content;
    private int fragmentIndex;
    private boolean isLast;

    public ResourceFragment(ResourceSummary resourceSummary, InputStream content, int fragmentIndex, boolean isLast) {
        try {
            this.resourceSummary = resourceSummary;
            this.content = IOUtils.toByteArray(content);
            this.fragmentIndex = fragmentIndex;
            this.isLast = isLast;
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(),e);
        }
    }

    public ResourceSummary getResourceSummary() {
        return resourceSummary;
    }

    public InputStream getContent() {
        return new ByteArrayInputStream(content);
    }

    public int getFragmentIndex() {
        return fragmentIndex;
    }

    public boolean isLast() {
        return isLast;
    }

    public ByteBuffer getContentAsByteBuffer() {
        return ByteBuffer.wrap(content);
    }

    public int getFragmentSize() {
        return content.length;
    }
}
