package com.scb.channels.foundation.contentcache.repository;

import com.scb.channels.foundation.contentcache.model.Readership;

import java.util.Collection;

public interface AnalyticsRepository extends Repository {

    void persistReadership(Readership readership);

    Collection<Readership> loadReadership();
}
