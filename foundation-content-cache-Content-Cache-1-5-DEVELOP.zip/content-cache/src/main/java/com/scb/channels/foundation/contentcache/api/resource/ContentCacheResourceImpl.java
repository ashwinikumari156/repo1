package com.scb.channels.foundation.contentcache.api.resource;

import com.datastax.driver.core.utils.UUIDs;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.channels.foundation.api.dto.contentcache.ResourceFilter;
import com.scb.channels.foundation.contentcache.api.dto.Resource;
import com.scb.channels.foundation.contentcache.api.dto.ResourceLinks;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.AnalyticsRepository;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import com.scb.channels.foundation.contentcache.util.FileUtils;
import com.scb.channels.foundation.contentcache.util.ResourceUtil;
import com.scb.channels.foundation.models.ContentDescriptor;
import com.scb.channels.foundation.util.jackson.Marshaller;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.Authorization;
import net.minidev.json.JSONObject;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.scb.channels.foundation.api.resource.filters.CacheControlFilter.CACHE_CONTROL_HDR;

@Path("/content")
@Produces({MediaType.APPLICATION_JSON, "application/pdf", "application/zip"})
public class ContentCacheResourceImpl implements ContentCacheResource {
    private final Logger logger = LoggerFactory.getLogger(ContentCacheResourceImpl.class);

    public static final String PAYLOAD = "payload";
    private ContentCacheService contentCacheService;
    private Marshaller marshaller;
    private ContentCacheContext contentCacheContext;
    private AnalyticsRepository analyticsRepository;

    @Autowired
    public ContentCacheResourceImpl(ContentCacheService contentCacheService, Marshaller marshaller, ContentCacheContext contentCacheContext,
                                    AnalyticsRepository analyticsRepository) {
        this.contentCacheService = contentCacheService;
        this.marshaller = marshaller;
        this.contentCacheContext = contentCacheContext;
        this.analyticsRepository = analyticsRepository;
    }


    @GET
    @Path("/{applicationId}/resId/{resId}")
    @ApiOperation(value = "Get application content by classification and resource id",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getResourceByResourceId(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                            @ApiParam(required = true) @PathParam("resId") String resourceId) {
        validateRequest(applicationId, resourceId);
        ResourceEntity resourceEntity = contentCacheService.resourceByResourceId(applicationId, resourceId, contentCacheContext);
        ResourceUtil.notFoundIfNull(resourceEntity, String.format("Resource not found for applicationId: %s, resourceId: %s", applicationId, resourceId));
        trackReadership(contentCacheContext, resourceEntity);
        String contentType = FileUtils.readFromPropertyFile("content_type_mapping.properties", FilenameUtils.getExtension(resourceId));
        return response(resourceEntity, true, MediaType.valueOf(contentType));
    }


    @GET
    @Path("/{applicationId}/cls/{classification}/resId/{resId}")
    @ApiOperation(value = "Get application content by classification and resource id",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getResourceByClassificationAndResourceId(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                             @ApiParam(required = true) @PathParam("classification") String classification,
                                                             @ApiParam(required = true) @PathParam("resId") String resourceId) {
        validateRequest(applicationId, classification, resourceId);
        ResourceEntity resourceEntity = contentCacheService.resourceByClassificationAndResourceId(applicationId, classification, resourceId, contentCacheContext);

        ResourceUtil.notFoundIfNull(resourceEntity, String.format("Resource not found for applicationId: %s, classification: %s, resourceId: %s ", applicationId
                , classification, resourceId));
        String contentType = FileUtils.readFromPropertyFile("content_type_mapping.properties", FilenameUtils.getExtension(resourceId));
        return response(resourceEntity, false, MediaType.valueOf(contentType));
    }


    @GET
    @Path("/{applicationId}/subCls/{subClassification}/cls/{classification}/resId/{resId}")
    @ApiOperation(value = "Get application content by subclassification, classification, and resourceId",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getResourceBySubClsAndClassificationAndResourceId(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                                      @ApiParam(required = true) @PathParam("subClassification") String subClassification,
                                                                      @ApiParam(required = true) @PathParam("classification") String classification,
                                                                      @ApiParam(required = true) @PathParam("resId") String resourceId) {
        validateRequest(applicationId, subClassification, classification, resourceId);
        ResourceEntity resourceEntity = contentCacheService.resourceById(applicationId, subClassification, classification, resourceId, contentCacheContext);
        ResourceUtil.notFoundIfNull(resourceEntity, String.format("Resource not found for applicationId: %s, subClassification: %s, classification: %s, resourceId: %s ",
                applicationId, subClassification, classification, resourceId));
        String contentType = FileUtils.readFromPropertyFile("content_type_mapping.properties", FilenameUtils.getExtension(resourceId));
        return response(resourceEntity, false, MediaType.valueOf(contentType));
    }


    @POST
    @Path("/list")
    @ApiOperation(value = "Get application content list by subclassification, classification, and resourceId",
            response = Object.class,
            httpMethod = "POST")
    @Override
    public Response getResourcesBySubClsAndClassificationAndResourceId(@ApiParam(required = true) String body) {
        validateRequest(body);
        ResourceFilter resourceRequest = marshaller.unmarshalLenient(body, ResourceFilter.class);
        Collection<ResourceEntity> resourceEntities = contentCacheService.resourceByIds(resourceRequest, contentCacheContext);

        ResourceUtil.notFoundIfEmpty(resourceEntities, "Resource not found");
        Map<String, List<JSONObject>> map = new HashMap<>();
        map.put(PAYLOAD, resourceEntities.stream().filter(d -> d != null).map(d ->
                getJsonObject(d)).collect(Collectors.toList()));
        return Response.ok(map).build();
    }


    @GET
    @Path("/{applicationId}/subCls/{subClassification}/cls/{classification}")
    @ApiOperation(value = "Get application content by classification and subclassification",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getResourceBySubClassificationAndClassification(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                                    @ApiParam(required = true) @PathParam("subClassification") String subClassification,
                                                                    @ApiParam(required = true) @PathParam("classification") String classification) {
        validateRequest(applicationId, classification, subClassification);
        Collection<ResourceEntity> data = contentCacheService.resourceBySubClassificationAndClassification(applicationId, subClassification, classification, contentCacheContext);
        ResourceUtil.notFoundIfEmpty(data, "Resource not found");
        Map<String, List<JSONObject>> map = new HashMap<>();
        map.put(PAYLOAD, data.stream().filter(d -> d != null).map(d ->
                getJsonObject(d)).collect(Collectors.toList()));
        return Response.ok(map, data.stream().findFirst().get().getResourceSummary().getContentType()).build();
    }


    @GET
    @Path("/composite/{applicationId}/subCls/{subClassification}/cls/{classification}")
    @ApiOperation(value = "Get application composite content by classification and subclassification",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getCompositeResourceBySubClassificationAndClassification(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                                             @ApiParam(required = true) @PathParam("subClassification") String subClassification,
                                                                             @ApiParam(required = true) @PathParam("classification") String classification) {
        validateRequest(applicationId, classification, subClassification);
        Collection<ResourceEntity> data = contentCacheService.resourceBySubClassificationAndClassification(applicationId, subClassification, classification, contentCacheContext);
        ResourceUtil.notFoundIfEmpty(data, String.format("Resource not found for classification: [%s] - subClassification: [%s]", classification, subClassification));
        return Response.ok(getJsonObject(data.stream().findFirst().get()), data.stream().findFirst().get().getResourceSummary().getContentType()).build();
    }


    @GET
    @Path("/{applicationId}/cls/{classification}")
    @ApiOperation(value = "Get application content by classification",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getResourceByClassification(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                @ApiParam(required = true) @PathParam("classification") String classification) {
        validateRequest(applicationId, classification);
        Collection<ResourceEntity> data = contentCacheService.resourceByClassification(applicationId, classification, contentCacheContext);
        ResourceUtil.notFoundIfEmpty(data, "Resource not found");
        Map<String, List<JSONObject>> map = new HashMap<>();
        map.put(PAYLOAD, data.stream().filter(d -> d != null).map(d ->
                getJsonObject(d)).collect(Collectors.toList()));
        return Response.ok(map, data.stream().findFirst().get().getResourceSummary().getContentType()).build();
    }


    @GET
    @Path("/composite/{applicationId}/cls/{classification}")
    @ApiOperation(value = "Get application content by classification",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getCompositeResourceByClassification(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                         @ApiParam(required = true) @PathParam("classification") String classification) {
        ResourceEntity resourceEntity = contentCacheService.compositeResourceByClassification(applicationId, classification, contentCacheContext);
        ResourceUtil.notFoundIfNull(resourceEntity, "Resource not found");
        return response(resourceEntity, false);
    }


    @GET
    @Path("/list/{applicationId}/cls/{classification}")
    @ApiOperation(value = "Lists available content for a given application and content type, list contains only link references.",
            notes = "This function is meant for management and service usage, it is not expected that the content should be directly exposed to a UI",
            response = ResourceLinks.class,
            httpMethod = "GET")
    @Override
    public ResourceLinks getResourceLinksByClassification(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                                          @ApiParam(required = true) @PathParam("classification") String classification) {
        return contentCacheService.resourceLinksByClassification(applicationId, classification);
    }


    @POST
    @Path("")
    @ApiOperation(value = "PUT resource contents",
            code = HttpStatus.SC_NO_CONTENT,
            httpMethod = "POST",
            authorizations = {@Authorization(value = "basicAuth")})
    @Override
    public Response putContent(@ApiParam(required = true) Resource resource) {
        Pair<InputStream, String> content = getInputStream(resource.getContentDescriptor());
        ResourceSummary summary = ResourceSummary.builder()
                .applicationId(resource.getHeader().getApplicationId())
                .classification(resource.getHeader().getClassification())
                .subClassification(resource.getHeader().getSubClassification())
                .resourceId(resource.getHeader().getResourceId())
                .createdAt(Instant.now())
                .build();

        ResourceEntity entity = new ResourceEntity(
                summary,
                content.getKey()
        );

        contentCacheService.persistResource(entity);

        return Response.noContent().build();
    }


    private Pair<InputStream, String> getInputStream(ContentDescriptor contentDescriptor) {
        try {
            return Pair.of(contentDescriptor.getRawContent(), contentDescriptor.getContentType());
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    private JSONObject getJsonObject(ResourceEntity r) {
        ObjectMapper mapper = new ObjectMapper();
        JSONObject object = null;
        try {
            object = mapper.readValue(r.getContent(), JSONObject.class);
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
        return object;
    }

    private Response response(ResourceEntity resourceEntity, boolean addCacheStrategy) {
        Response.ResponseBuilder response = Response.ok(resourceEntity.getContent(), resourceEntity.getResourceSummary().getContentType())
                .header("applicationId", resourceEntity.getResourceSummary().getApplicationId())
                .header("createdAt", resourceEntity.getResourceSummary().getCreatedAt())
                .header("classification", resourceEntity.getResourceSummary().getClassification())
                .header("subClassification", resourceEntity.getResourceSummary().getSubClassification())
                .header("documentId", resourceEntity.getResourceSummary().getResourceId());

        if (addCacheStrategy) {
            response.header(CACHE_CONTROL_HDR, "private, max-age=900, s-maxage=900");
        }
        return response.build();
    }

    private Response response(ResourceEntity resourceEntity, boolean addCacheStrategy, MediaType mediaType) {
        Response.ResponseBuilder response = Response.ok(resourceEntity.getContent(), resourceEntity.getResourceSummary().getContentType())
                .header("applicationId", resourceEntity.getResourceSummary().getApplicationId())
                .header("createdAt", resourceEntity.getResourceSummary().getCreatedAt())
                .header("classification", resourceEntity.getResourceSummary().getClassification())
                .header("subClassification", resourceEntity.getResourceSummary().getSubClassification())
                .header("documentId", resourceEntity.getResourceSummary().getResourceId());

        if (addCacheStrategy) {
            response.header(CACHE_CONTROL_HDR, "private, max-age=900, s-maxage=900");
        }
        response.type(mediaType != null ? mediaType : MediaType.valueOf(MediaType.APPLICATION_JSON));
        return response.build();
    }

    private void validateRequest(String... data) {
        Arrays.asList(data).stream().forEach(d ->
                ResourceUtil.badRequestIfNull(d, "Missing request params"));
    }

    private void trackReadership(ContentCacheContext contentCacheContext, ResourceEntity resourceEntity) {
        if (StringUtils.isBlank(resourceEntity.getResourceSummary().getContentType())
                || !resourceEntity.getResourceSummary().getContentType().contains("pdf")) {
            return;
        }
        analyticsRepository.persistReadership(Readership.builder()
                .userId(contentCacheContext.getUserId())
                .resourceId(resourceEntity.getResourceSummary().getResourceId())
                .applicationId(resourceEntity.getResourceSummary().getApplicationId())
                .id(UUIDs.timeBased() + "")
                .createdAt(Instant.now())
                .build());
    }

}
