package com.scb.channels.foundation.contentcache.util;


public interface ContentCacheConstants {

    String TABLE_RESOURCE_BY_ID = "resource_by_id";
    String VIEW_RESOURCE_BY_CLS="resource_by_cls";
    String VIEW_RESOURCE_BY_CLS_RESID="resource_by_cls_resid";
    String VIEW_RESOURCE_BY_SUBCLS="resource_by_subcls";
    String TABLE_READERSHIP_BY_ID = "readership_by_id";
    String COLUMN_IS_LAST = "isLast";
    String COLUMN_RESOURCE_ID = "id";
    String COLUMN_RESOURCE_RESID = "resourceId";
    String COLUMN_APPLICATION_ID = "applicationId";
    String COLUMN_CONTENT = "content";
    String COLUMN_CONTENT_TYPE = "contentType";
    String COLUMN_CREATED_AT = "createdAt";
    String COLUMN_MESSAGE_TIMESTAMP = "messageTimestamp";
    String COLUMN_SEGMENT_ID = "segmentId";
    String COLUMN_CLASSIFICATION = "classification";
    String COLUMN_SUB_CLASSIFICATION = "subClassification";
    String COLUMN_SEGMENT_SIZE = "segmentSize";
    String COLUMN_COMPOUND_CLS_RESID = "appIdClsResIdConcat";
    String COLUMN_COMPOUND_CLS_SUBCLS ="appIdSubClsClsConcat";
    String COLUMN_COMPOUND_CLS ="appIdClsConcat";
    String COLUMN_DAP_TOPIC="dapTopic";
    String COLUMN_MD5HASH = "md5hash";
    String COLUMN_DELETED = "deleted";
    int MAX_CHUNK_SIZE = 100000;

    String COLUMN_READERSHIP_ID="id";
    String COLUMN_USERID="userId";

}
