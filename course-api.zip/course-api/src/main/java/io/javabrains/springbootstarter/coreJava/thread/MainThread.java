package io.javabrains.springbootstarter.coreJava.thread;


public class MainThread {
    public static void main(String[] args) {
        Thread t = Thread.currentThread();
        System.out.println("Main thread name: "+ t.getName());

        t.setName("Geek");
        System.out.println("Main thread new name: "+ t.getName());

        System.out.println("Mian thread defaukt priority: "+ t.getPriority());

        t.setPriority(7);
        System.out.println("Mian thread new priority: "+ t.getPriority());

        for (int i=0; i<5; i++){
            System.out.println("Main thread");
        }

        ChildThread c = new ChildThread();

        System.out.println("Child thread name: "+c.getName());
        c.setName("Child");
        System.out.println("Child thread new name: "+ c.getName());
        System.out.println("Child thread priority : "+ c.getPriority());
        c.start();
    }
}

class ChildThread extends Thread{
    public void run(){
        for (int i=0; i<5; i++) {
            System.out.println("Child thread");
        }
    }
}
