package io.javabrains.springbootstarter.coreJava.demo;


import java.util.Scanner;
import java.util.TreeSet;

public class StringDemo {
    public static void main(String[] args) {
        System.out.println("String in use");

        String s = "research portal";
        String s1 = "global research portal";

        System.out.println("String concatenation: " + s.concat(s1));
        System.out.println("String substring : " + s.substring(7, s.length() - 1));

        System.out.println("String test :" + s1.replace("re", " "));

        String a1 = "hello";
        String a2 = "hello";

        //with equal()
        if (a1.equals(a2)) {
            System.out.println("string equal");
        } else {
            System.out.println("string not equal");
        }

        //w/o equal()
        int len1 = a1.length();
        int len2 = a2.length();
        char[] num1 = a1.toCharArray();
        char[] num2 = a2.toCharArray();
        if (len1 != len2) {
            System.out.println("length not equal");
        } else {
            boolean isEqual = true;
            for (int i = 0; i < len1; i++) {
                if (num1[i] != num2[i]) {
                    System.out.println("Strings are not equal");
                    isEqual = false;
                    break;
                }
            }
            if (isEqual) {
                System.out.println("strings are equal");
            }
        }

        //substring
        String x1 = "Today is tuesday";
        char[] x1Char = x1.toCharArray();
        Scanner begIndex = new Scanner(System.in);
        Scanner endIndex = new Scanner(System.in);
        char[] result = new char[0];
        int begNum = begIndex.nextInt();
        int endNum = endIndex.nextInt();
        //result[2]='u';
        char t;
        for (int i = 0; i < x1Char.length; i++) {
            if (i >= begNum || i < endNum) {
                System.out.println("Substring of x1 : " + x1Char[i]);
            } else {
                result[i] = 0;
            }

        }


        TreeSet<String> test = new TreeSet<>();
        test.add("A");
        test.add("C");
        test.add("B");
        System.out.println(test);

        //String Reversal
        String revString = "good";
        System.out.println("Reversal of string starts");
        //withour recursion
        String res = new String();
        int l=revString.length();
        for (int i=1; i<=l; i++) {
            if (revString == null || revString.length() <= 0) {
                System.out.println(revString);
            } else {
                res=res+revString.charAt(revString.length()-1);
                revString=revString.substring(0,revString.length()-1);
            }
        }
        System.out.println("Reversed String without recursion: " + res);

        String w="good";
        System.out.println("Returned String : " + reverse(w));

    }

    public static String reverse(String str) {
        if (str == null || str.length() <= 0) {
            return str;
        } else {
            return reverse(str.substring(1)) + str.charAt(0);
        }
    }
}
