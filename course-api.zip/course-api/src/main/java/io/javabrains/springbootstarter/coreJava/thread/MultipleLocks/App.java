package io.javabrains.springbootstarter.coreJava.thread.MultipleLocks;


public class App {
    public static void main(String[] args) {
        Worker worker= new Worker();
        worker.main();
    }
}
