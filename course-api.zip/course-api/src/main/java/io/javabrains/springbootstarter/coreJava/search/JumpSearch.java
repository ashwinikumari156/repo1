package io.javabrains.springbootstarter.coreJava.search;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class JumpSearch {
    public static void main(String[] args) {
        int arr[]={10,12,23,25,34,56,57,58,89};
        int x=58;
        int i=jSearch(arr,x);
        if(i<0)
            System.out.println("Number not found");
        else
            System.out.println("Number "+x+" found at index "+i);
    }
    public static int jSearch(int arr[], int x){
        int len=arr.length;
        int jump=(int)Math.floor(Math.sqrt(len));
        int prev=0;
        for(int i=jump; i<len; i=jump*2){
            if(x==arr[i])
                return i;
            else if(x<arr[i]){
                for(int j=i/2; j<i; j++)
                    if(x==arr[j])
                        return j;
            }
        }
        return -1;
    }
}
