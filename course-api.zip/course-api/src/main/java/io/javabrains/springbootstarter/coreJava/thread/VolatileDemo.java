package io.javabrains.springbootstarter.coreJava.thread;


import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class VolatileDemo implements Runnable{

    //volatile is used to prevent threads caching variables when they are not changed
    //and from within that thread. in case if u want to change a variable from another thread use volatile or sync.

    private volatile boolean runner=true;
    @Override
    public void run() {
        while(runner) {
            System.out.println("Hello");
            try {
                TimeUnit.MILLISECONDS.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void shutDown() {
        runner =false;
    }
}
class App {
    public static void main(String[] args) {
        VolatileDemo v = new VolatileDemo();
        Thread t = new Thread(v);
        t.start();

        System.out.println("Enter return to stop");
        Scanner sc= new Scanner(System.in);
        sc.nextLine();
        v.shutDown();
    }
}
