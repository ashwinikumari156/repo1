package io.javabrains.springbootstarter.coreJava.thread;


public class ThreadWaitAndNotify {
    public static void main(String[] args) {
        Calculator cal = new Calculator();
        cal.start();
        synchronized (cal) {
            try {
                cal.wait();
            } catch(InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(cal.sum);
    }
}

class Calculator extends Thread{
    long sum;

    @Override
    public void run() {
        synchronized (this) {
            for(int i=0; i<1000000; i++){
                sum+=i;
            }
            notify();
        }
    }

}
