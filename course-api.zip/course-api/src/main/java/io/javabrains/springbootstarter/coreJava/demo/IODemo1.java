package io.javabrains.springbootstarter.coreJava.demo;


import java.io.*;

public class IODemo1 {
    public static void main(String[] args) {
        try {
            /*ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("numbers.bin"));
            for (int i = 0; i < 10; i++) {
                os.writeInt(i);
            }*/

            ObjectInputStream oi = new ObjectInputStream(new FileInputStream("numbers.bin"));
            for (int i = 0; i < 9; i++) {
                int num = oi.readInt();
                System.out.println("print" + num);
            }
            //os.close();
            oi.close();
        }
        catch(EOFException e){
            System.out.println("IO Exception");
        }catch(IOException e){
            System.out.println("End of file");
        }
    }
}
