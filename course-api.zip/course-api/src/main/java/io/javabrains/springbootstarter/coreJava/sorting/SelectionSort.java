package io.javabrains.springbootstarter.coreJava.sorting;


public class SelectionSort {

    public static void main(String[] args) {
        int arr[] = {7, 10, 10, 56, 32, 4, 2, 5};
        selection(arr);
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void selection(int arr[]) {
        int temp, index, len = arr.length;
        for (int x = 0; x < len; x++) {
            System.out.print(arr[x] + " ");
        }
        System.out.println();

        for (int i = 0; i < len - 1; i++) {
            index = i;
            for (int j = i + 1; j < len; j++) {
                if (arr[index] > arr[j])
                    index = j;
            }
            temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;

            System.out.print(i + 1 + " Iteration:  ");
            for (int k = 0; k < len; k++) {
                System.out.print(arr[k] + " ");
            }
            System.out.println("");
        }
    }
}
