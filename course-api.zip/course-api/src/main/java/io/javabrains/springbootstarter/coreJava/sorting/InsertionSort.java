package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class InsertionSort {
    public static void main(String[] args) {
        int arr[]={9,8,7,6,5,4,56,23,1};
        iSort(arr);
        for(int i=0; i<arr.length; i++){
            System.out.print(arr[i]+ " ");
        }
    }
    public static void iSort(int arr[]){
        int temp=0,len=arr.length;
        for(int i=1; i<len; i++){
            for(int j=0; j<i; j++){
                if(arr[j]>arr[i]) {
                    temp = arr[i];
                    for (int k = i; k > j; k--) {
                        arr[k] = arr[k - 1];
                    }
                    arr[j] = temp;
                }
            }
        }
    }
}
