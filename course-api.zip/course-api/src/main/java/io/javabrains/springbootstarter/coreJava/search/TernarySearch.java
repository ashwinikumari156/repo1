package io.javabrains.springbootstarter.coreJava.search;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class TernarySearch {
    public static void main(String[] args) {
        int arr[]={1,2,3,4,5,6,7,8,9,10};
        int x=10;
        int i=tSearch(arr, 0, arr.length-1, x);
        if(i<0)
            System.out.println("Number not found");
        System.out.println("Number "+x+" found at index "+i);
    }
    public static int tSearch(int arr[], int l, int r, int x){
        int mid1=l+(r-l)/3;
        int mid2=mid1+(r-l)/3;
        if(l<=r){
            if(x==arr[mid1])
                return mid1;
            else if(x==arr[mid2])
                return mid2;
            else if(x<arr[mid1])
                return tSearch(arr, l, mid1-1, x);
            else if(x>arr[mid2])
                return tSearch(arr, mid2+1, r, x);
            return tSearch(arr, mid1+1, mid2-1, x);
        }
        return -1;
    }
}
