package io.javabrains.springbootstarter.coreJava.sorting;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class BubbleSort {
    public static void main(String[] args) {
        int arr[]={5, 1, 4, 2, 8};
        bSort(arr);
        for(int i=0; i<arr.length; i++)
            System.out.print(arr[i]+" ");
    }
    public static void bSort(int arr[]){
        int temp, pass=1, len=arr.length;
        while(pass<len){
            System.out.print("Pass "+pass+": ");
            for(int i=0; i<len-1; i++){
                if(arr[i]>arr[i+1]){
                    temp=arr[i];
                    arr[i]=arr[i+1];
                    arr[i+1]=temp;
                }
            }
            for(int j=0; j<len; j++){
                System.out.print(" "+arr[j]+" ");
            }
            System.out.println(" ");
            pass++;
        }
        // copied from geeksforgeek
        /*int n = arr.length,pass=1;
        for (int i = 0; i < n-1; i++){
            System.out.print("Pass "+pass+": ");
            for (int j = 0; j < n-i-1; j++)
                if (arr[j] > arr[j+1])
                {
                    // swap temp and arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            for(int j=0; j<n; j++){
                System.out.print(" "+arr[j]+" ");
            }
            System.out.println(" ");
            pass++;
        }*/

    }

}
