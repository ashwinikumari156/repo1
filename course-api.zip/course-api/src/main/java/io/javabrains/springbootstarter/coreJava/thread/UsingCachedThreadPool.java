package io.javabrains.springbootstarter.coreJava.thread;


import io.javabrains.springbootstarter.coreJava.thread.common.LoopRunnableTaskA;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UsingCachedThreadPool {
    public static void main(String[] args) {
        System.out.println("######################## Main starts here ######################");
        ExecutorService executorService= Executors.newCachedThreadPool();
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.execute(new LoopRunnableTaskA());
        executorService.shutdown();
        System.out.println("####################### Mian ends here #########################");
    }
}
