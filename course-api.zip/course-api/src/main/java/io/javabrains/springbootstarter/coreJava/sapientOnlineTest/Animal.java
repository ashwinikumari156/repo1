package io.javabrains.springbootstarter.coreJava.sapientOnlineTest;

/**
 * Created by 1554439 on 3/12/2018.
 */
/*public class Animal implements Runnable {
    public void run(){
        try{
            for(int i=0; i<4; i++){
                Thread.sleep(100);
                System.out.println(Thread.currentThread().getName());
            }
        }catch(InterruptedException e){

        }
    }

    *//*public Animal(){
        *//**//*Thread a=new Thread(this);
        a.start();*//**//*
    }*//*

}

class Test {
    public static void main(String[] args) throws InterruptedException {
        Animal a= new Animal();
        Thread t= new Thread(a, "A");
        Thread t1= new Thread(a, "B");
        t.start();
        t.join();
        t1.start();
    }
}*/


public class Animal extends Thread {
    static volatile int i;

    public void run() {
        //System.out.println("before"+i);
        i++;
        System.out.println("after" + i);
    }

    public static void main(String[] args) {
        Animal a = new Animal();
        //a.run();
        System.out.println(i);
        a.start();
        System.out.println(i);
    }

}


