package io.javabrains.springbootstarter.coreJava.thread.MultipleLocks;


public class Worker {
    public void main() {
        System.out.println("Hello");
    }
}
