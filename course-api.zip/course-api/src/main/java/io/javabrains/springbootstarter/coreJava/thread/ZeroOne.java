package io.javabrains.springbootstarter.coreJava.thread;

/**
 * Created by 1554439 on 1/23/2018.
 */
public class ZeroOne {
}
