package io.javabrains.springbootstarter.coreJava.search;

/**
 * Created by 1554439 on 3/19/2018.
 */
public class BinarySearch {
    public static void main(String[] args) {
        int arr[]={9,10,23,30,34,45,67};
        int x=9;
        int l=0;
        int r=arr.length-1;
        int i=bSearch(arr,l,r,x);
        if(i<0)
            System.out.println("Number not found");
        else
            System.out.println("Number "+x+" found at index "+i);
    }

    public static int bSearch(int arr[], int l, int r, int x){
        int m=l+(r-l)/2;
        if(l<=r){
            if(x==arr[m])
                return m;
            else if(x<arr[m]){
                return bSearch(arr, l, m-1, x);
            }
            else
                return bSearch(arr, m+1, r, x);
        }

        return -1;
    }
}
