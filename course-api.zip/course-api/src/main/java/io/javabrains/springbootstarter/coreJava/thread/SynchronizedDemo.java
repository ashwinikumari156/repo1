package io.javabrains.springbootstarter.coreJava.thread;


public class SynchronizedDemo {

    private int count=0;

    /*public synchronized void syn() {
        count++;
    }*/

    public static void main(String[] args) {
        System.out.println("########### Main thread starts here");
        SynchronizedDemo syn = new SynchronizedDemo();
        syn.doWork();
        System.out.println("########### Main thread ends here");
    }

    public void doWork() {
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("First Thread starts here");
                for(int i=0; i<1000; i++){
                    count++;
                    //syn();
                }
            }
        });

        Thread t2= new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Second thread starts here");
                for(int i=0; i<1000; i++){
                    count++;
                    //syn();
                }
            }
        });

        t1.start();
        t2.start();

        try {
            t1.join();  //join()  will return untill t1 is finished
            t2.join();  // join() will return uuntill t2 is finished
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println(count);

    }

}
