package io.javabrains.springbootstarter.coreJava.thread;

import java.util.ArrayList;

/**
 * Created by 1554439 on 1/23/2018.
 */
public class OddEven extends Thread{
    public void run(){
        System.out.println("Odd numbers: ");
    }
}

class Even extends Thread{
    public void run(){
        System.out.println("Even numbers: ");
    }
}

class OEMain{
    public static void main(String[] args) {
        OddEven o=new OddEven();
        Even e= new Even();
        ArrayList<Integer> array=new ArrayList<>();
        array.add(1);
        array.add(2);
        array.add(3);
        array.add(4);

        System.out.println("array elements: "+array);

        int len=array.size();

        for(int i=0; i<len; i++){
            if(array.get(i)%2==0){
                System.out.println("EVEN");
                e.start();
            }else{
                System.out.println("ODD");
                o.start();
            }
        }

    }
}