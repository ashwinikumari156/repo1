package io.javabrains.springbootstarter.coreJava.demo;


public class ExceptionDemo {
    public static void main(String[] args) {
        //test();
        test1();
    }
    /*static void test() {
        try {
            System.out.println("try");
            throw new RuntimeException();
        } catch(Exception e) {
            System.out.println("catch");
        } finally {
            System.out.println("finally");
        }
    }*/

    static void test1() throws  ArithmeticException{
        System.out.println("THROWS and Throw");
        int i=5, b=0, c;
        if (b==0){
            throw new ArithmeticException();
        }else{
            c=i/b;
        }
    }
}
