package com.scb.channels.foundation.contentcache.repository;

import com.datastax.driver.core.Row;
import com.google.common.collect.ImmutableList;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.util.ContentCacheConstants;
import com.scb.channels.persistence.*;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.scb.channels.foundation.util.DateUtils.toTimestamp;
import static com.scb.channels.persistence.PersistableColumn.column;

@Component
public class AnalyticsRepositoryImpl extends AbstractRepository implements AnalyticsRepository, ContentCacheConstants {

    private PersistenceService persistenceService;

    public AnalyticsRepositoryImpl(PersistenceService persistenceService) {
        this.persistenceService = persistenceService;
    }

    @Override
    public PersistenceService persistenceService() {
        return persistenceService;
    }


    @Override
    public void persistReadership(Readership readership) {
        PersistableBatchBuilder persistableBatchBuilder = newBatch();
        persistableBatchBuilder.add(persistableFor(readership));
        persistableBatchBuilder.execute();
    }

    @Override
    public Collection<Readership> loadReadership() {
        return persistenceService.retrieve(
                Loadables.<Collection<Readership>>builder()
                        .targetTable(TABLE_READERSHIP_BY_ID)
                        .keyValues(new HashMap<>())
                        .unmarshallingStrategy(resultSet -> StreamSupport.stream(resultSet.spliterator(), false)
                                .map(this::fromRow)
                                .collect(Collectors.toList()))
                        .build());
    }

    private Readership fromRow(Row row) {
        return Readership.builder()
                .id(row.getString(COLUMN_READERSHIP_ID))
                .createdAt(row.getTimestamp(COLUMN_CREATED_AT).toInstant())
                .userId(row.getString(COLUMN_USERID))
                .resourceId(row.getString(COLUMN_RESOURCE_RESID))
                .applicationId(row.getString(COLUMN_APPLICATION_ID))
                .build();
    }

    private List<Persistable<Readership>> persistableFor(Readership readership) {
        Persistable<Readership> persistableContent = Persistables.<Readership>builder()
                .object(readership)
                .targetTable(TABLE_READERSHIP_BY_ID)
                .type(Persistable.Type.Upsert)
                .keyDefinition(KeyDefinitions.singleton(COLUMN_READERSHIP_ID, COLUMN_READERSHIP_ID))
                .marshallingStrategy(readershipMarshallingStrategy())
                .build();

        return ImmutableList.of(persistableContent);
    }

    private MarshallingStrategy<Readership> readershipMarshallingStrategy() {
        return readership -> ImmutableList
                .<PersistableColumn>builder()
                .add(column(COLUMN_READERSHIP_ID, readership.getId()))
                .add(column(COLUMN_USERID, readership.getUserId()))
                .add(column(COLUMN_RESOURCE_RESID, readership.getResourceId()))
                .add(column(COLUMN_CREATED_AT, toTimestamp(readership.getCreatedAt())))
                .add(column(COLUMN_APPLICATION_ID, readership.getApplicationId()))
                .build();
    }

}
