package com.scb.channels.foundation.contentcache.consumer;

public interface MessageHandler {

    void processMessage(String message);
}
