package com.scb.channels.foundation.contentcache.api.resource;

import com.scb.channels.foundation.api.resource.ExceptionHandlerProvider;
import com.scb.channels.foundation.api.resource.filters.CORSResponseFilter;
import com.scb.channels.foundation.api.resource.filters.CacheControlFilter;
import com.scb.channels.foundation.util.jackson.ObjectMapperProvider;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.boot.logging.Slf4JLoggingSystem;
import org.springframework.context.annotation.Configuration;

import java.util.logging.Level;
import java.util.logging.Logger;

import static com.scb.channels.foundation.api.resource.SwaggerUtil.initSwagger;

@Configuration
public class ApplicationResourceConfig extends ResourceConfig {

    private static final String TITLE = "Content Cache";

    public ApplicationResourceConfig() {

        register(ContentCacheResourceImpl.class);
        register(AnalyticsResourceImpl.class);
        register(ReconResourceImpl.class);
        register(ExceptionHandlerProvider.class);
        register(ObjectMapperProvider.class);
        register(CORSResponseFilter.class);
        register(CacheControlFilter.class);
        registerJerseyLogger();
        initSwagger(TITLE, this);
    }

    private void registerJerseyLogger() {
        String loggingCategory = Slf4JLoggingSystem.class.getCanonicalName();
        register(new LoggingFeature(Logger.getLogger(loggingCategory),
                Level.INFO,
                LoggingFeature.Verbosity.PAYLOAD_TEXT,
                null));
    }

}

