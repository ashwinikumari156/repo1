package com.scb.channels.foundation.contentcache.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ReadershipAnalytics {
    private int sequenceNumber;
    private String resourceId;
    private String formattedResourceId;

    @JsonIgnore
    private Integer readCount;

    public ReadershipAnalytics(String resourceId, String formattedResourceId, Integer readCount, int sequenceNumber) {
        this.resourceId = resourceId;
        this.formattedResourceId = formattedResourceId;
        this.readCount = readCount;
        this.sequenceNumber = sequenceNumber;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getFormattedResourceId() {
        return formattedResourceId;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

}
