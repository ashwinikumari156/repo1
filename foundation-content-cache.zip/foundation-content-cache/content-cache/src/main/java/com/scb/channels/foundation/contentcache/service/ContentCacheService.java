package com.scb.channels.foundation.contentcache.service;

import com.scb.channels.foundation.api.dto.contentcache.ResourceFilter;
import com.scb.channels.foundation.contentcache.api.dto.ResourceLinks;
import com.scb.channels.foundation.contentcache.api.resource.ContentCacheContext;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface ContentCacheService {

    ResourceEntity resourceById(String applicationId, String subClassification, String classification, String resourceId, ContentCacheContext contentCacheContext);

    ResourceEntity resourceByResourceId(String applicationId, String resourceId, ContentCacheContext contentCacheContext);

    Collection<ResourceEntity> resourceBySubClassificationAndClassification(String applicationId, String subClassification, String classification, ContentCacheContext contentCacheContext);


    Collection<ResourceEntity> resourceByClassification(String applicationId, String classification, ContentCacheContext contentCacheContext);
    ResourceEntity compositeResourceByClassification(String applicationId, String classification, ContentCacheContext contentCacheContext);


    ResourceEntity resourceByClassificationAndResourceId(String applicationId, String classification, String resourceId, ContentCacheContext contentCacheContext);

    Collection<ResourceEntity> resourceByIds(ResourceFilter resourceRequest, ContentCacheContext contentCacheContext);

    Collection<ResourceEntity> resourceByResourceIds(ResourceFilter resourceRequest, ContentCacheContext contentCacheContext);

    ResourceLinks resourceLinksByClassification(String applicationId, String classification);

    void persistResource(ResourceEntity resourceEntity);

    Map<String, ResourceSummary> resourceSummariesByClassificationAndResourceId(List<ResourceIdentifier> identifier, ContentCacheContext contentCacheContext);

}
