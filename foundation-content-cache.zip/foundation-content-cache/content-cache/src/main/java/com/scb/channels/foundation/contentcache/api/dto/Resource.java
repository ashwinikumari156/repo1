package com.scb.channels.foundation.contentcache.api.dto;

import com.scb.channels.foundation.models.ContentDescriptor;

public class Resource {

    private ResourceLink header;
    private ContentDescriptor contentDescriptor;

    public Resource() {

    }

    public Resource(ResourceLink header, ContentDescriptor contentDescriptor) {
        this.header = header;
        this.contentDescriptor = contentDescriptor;
    }

    public ResourceLink getHeader() {
        return header;
    }

    public ContentDescriptor getContentDescriptor() {
        return contentDescriptor;
    }
}
