package com.scb.channels.foundation.contentcache.config;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.ProtocolOptions;
import com.scb.channels.foundation.util.Passwords;
import com.scb.channels.foundation.util.jackson.JacksonMarshaller;
import com.scb.channels.foundation.util.jackson.Marshaller;
import com.scb.channels.persistence.PersistenceService;
import com.scb.channels.persistence.PersistenceServiceImpl;
import com.scb.channels.persistence.Store;
import com.scb.channels.persistence.cassandra.CassandraConfig;
import com.scb.channels.persistence.cassandra.CassandraStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CassandraEnvConfig {

    @Value("${cassandra.contactpoints}")
    private String contactPoints;

    @Value("${cassandra.keyspace}")
    private String keySpaceName;

    @Value("${cassandra.cluster.name}")
    private String clusterName;

    @Value("${cassandra.username}")
    private String userName;

    @Value("${cassandra.password}")
    private String password;

    @Value("${cassandra.datacenter.name}")
    private String dataCenterName;

    @Value("${cassandra.port}")
    private int port;

    @Bean
    public Store cassandraStore(CassandraConfig cassandraConfig) {
        return new CassandraStore(cassandraConfig);
    }


    @Bean
    public Marshaller marshaller() {
        return new JacksonMarshaller();
    }

    @Bean
    public PersistenceService persistenceService(Store cassandraStore) {
        return new PersistenceServiceImpl(cassandraStore);
    }

    @Bean(name = "cassandra-config")
    public CassandraConfig cassandraConfig() {
        CassandraConfig cassandraConfig = new CassandraConfig();
        cassandraConfig.setClusterFriendlyName(clusterName);
        cassandraConfig.setCompression(ProtocolOptions.Compression.LZ4);
        cassandraConfig.setContactPoints(contactPoints.split(","));
        cassandraConfig.setContactPort(port);
        cassandraConfig.setKeyspace(keySpaceName);
        cassandraConfig.setLocalDataCenter(dataCenterName);
        cassandraConfig.setMaxConnectionsPerHostLocal(4);
        cassandraConfig.setMaxConnectionsPerHostRemote(2);
        cassandraConfig.setReadConsistencyLevel(ConsistencyLevel.LOCAL_ONE);
        cassandraConfig.setWriteConsistencyLevel(ConsistencyLevel.LOCAL_ONE);
        cassandraConfig.setWriteSerialConsistencyLevel(ConsistencyLevel.SERIAL);
        cassandraConfig.setUsername(userName);
        cassandraConfig.setPassword(Passwords.decrypt(password));
        return cassandraConfig;
    }

    String[] getContactPointsAsArray() {
        return contactPoints.split(",");
    }

}
