package com.scb.channels.foundation.contentcache.model;

public enum  Action {

    delete
}
