package com.scb.channels.foundation.contentcache.model;

import com.scb.channels.foundation.util.ReflectionBuilder;

import java.time.Instant;

public class Readership {

    private String id;
    private String userId;
    private String resourceId;
    private Instant createdAt;
    private String applicationId;

    public interface ReadershipBuilder {
        ReadershipBuilder id(String id);
        ReadershipBuilder userId(String userId);
        ReadershipBuilder resourceId(String resourceId);
        ReadershipBuilder createdAt(Instant createdAt);
        ReadershipBuilder applicationId(String applicationId);
        Readership build();
    }

    public static ReadershipBuilder builder() {
        return ReflectionBuilder.builderFor(ReadershipBuilder.class);
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getResourceId() {
        return resourceId;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public String getApplicationId() {
        return applicationId;
    }

}
