package com.scb.channels.foundation.contentcache.api.resource;

import com.scb.channels.foundation.contentcache.api.dto.Resource;
import com.scb.channels.foundation.contentcache.api.dto.ResourceLinks;

import javax.ws.rs.core.Response;

public interface ContentCacheResource {

    Response getResourceByResourceId(String applicationId, String resourceId);

    Response getResourceByClassificationAndResourceId(String applicationId, String classification, String resourceId);

    Response getResourceBySubClsAndClassificationAndResourceId(String applicationId, String subClassification, String classification, String resourceId);

    Response getResourcesBySubClsAndClassificationAndResourceId(String body);

    Response getResourceBySubClassificationAndClassification(String applicationId, String subClassification, String classification);

    Response getCompositeResourceBySubClassificationAndClassification(String applicationId, String subClassification, String classification);

    Response getResourceByClassification(String applicationId, String classification);

    Response getCompositeResourceByClassification(String applicationId, String classification);


    /**
     * For Administration
     */
    ResourceLinks getResourceLinksByClassification(String applicationId, String classification);

    Response putContent(Resource resource);

}