package com.scb.channels.foundation.contentcache.api.dto;

import com.scb.channels.foundation.util.ReflectionBuilder;

public class ReadershipRawData {

    private String id;
    private String userId;
    private String resourceId;
    private String accessTime;

    public interface ReadershipRawDataBuilder {
        ReadershipRawDataBuilder id(String id);
        ReadershipRawDataBuilder userId(String userId);
        ReadershipRawDataBuilder resourceId(String resourceId);
        ReadershipRawDataBuilder accessTime(String accessTime);
        ReadershipRawData build();
    }

    public static ReadershipRawDataBuilder builder() {
        return ReflectionBuilder.builderFor(ReadershipRawDataBuilder.class);
    }

    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getAccessTime() {
        return accessTime;
    }
}
