package com.scb.channels.foundation.contentcache.api.resource;


import javax.ws.rs.core.Response;

public interface AnalyticsResource {

    Response getReadership(String applicationId, String startDate, String endDate);
    Response getReadershipForTheWeek(String applicationId);
    Response getReadershipForGivenDays(String applicationId,
                                       int days);
}
