package com.scb.channels.foundation.contentcache.api.resource;

import com.google.common.collect.ImmutableMap;
import com.scb.channels.foundation.contentcache.api.dto.ReadershipAnalytics;
import com.scb.channels.foundation.contentcache.api.dto.ReadershipRawData;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.AnalyticsRepository;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import com.scb.channels.foundation.contentcache.util.ResourceUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Path("/analytics")
@Produces({MediaType.APPLICATION_JSON, "application/pdf", "application/zip"})
public class AnalyticsResourceImpl implements AnalyticsResource {

    public static final String PAYLOAD = "payload";
    public static final String PDF = ".pdf";

    private AnalyticsRepository analyticsRepository;

    private ContentCacheService contentCacheService;

    private ContentCacheContext contentCacheContext;

    private static final int A_WEAK_AGO = 7;
    private static final int TOP_READ_RESULT_LIMIT = 10;

    @Autowired
    public AnalyticsResourceImpl(AnalyticsRepository analyticsRepository, ContentCacheService contentCacheService, ContentCacheContext contentCacheContext) {
        this.analyticsRepository = analyticsRepository;
        this.contentCacheService = contentCacheService;
        this.contentCacheContext = contentCacheContext;
    }

    @GET
    @Path("/readership/{applicationId}/{startTime}/{endTime}")
    @ApiOperation(value = "Get readership",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getReadership(@ApiParam(required = true) @PathParam("applicationId") String applicationId, @PathParam("startTime") String startDate,
                                  @PathParam("endTime") String endDate) {
        Instant startTime;
        Instant endTime;
        validateRequestParams(applicationId, startDate, endDate);
        try {
            startTime = Instant.parse(startDate);
            endTime = Instant.parse(endDate);
        } catch (Exception e) {
            throw new BadRequestException("Invalid date");
        }

        Collection<Readership> readerships = analyticsRepository.loadReadership();
        ResourceUtil.notFoundIfEmpty(readerships, "Readership not found");
        Map<String, List<ReadershipRawData>> map = new HashMap<>();

        List<ReadershipRawData> rawData = readerships.stream().map(r -> ReadershipRawData.builder()
                .userId(r.getUserId())
                .resourceId(r.getResourceId().replace(PDF, ""))
                .accessTime(r.getCreatedAt().toString())
                .id(r.getId())
                .build()).collect(Collectors.toList());


        List<ReadershipRawData> filteredrawData = rawData.stream().filter(r -> Instant.parse(r.getAccessTime()).isAfter(startTime)
                && Instant.parse(r.getAccessTime()).isBefore(endTime)).collect(Collectors.toList());
        map.put(PAYLOAD, filteredrawData);
        return Response.ok(map).build();
    }

    @GET
    @Path("/readershipForWeek/{applicationId}")
    @ApiOperation(value = "Get readership for the week",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getReadershipForTheWeek(@ApiParam(required = true) @PathParam("applicationId") String applicationId) {
        validateRequestParams(applicationId);
        return Response.ok(ImmutableMap.of(PAYLOAD, getReadershipAnalytics(A_WEAK_AGO, applicationId))).build();
    }

    @GET
    @Path("/readershipForWeek/{applicationId}/{duration}")
    @ApiOperation(value = "Get readership for the week",
            response = Object.class,
            httpMethod = "GET")
    @Override
    public Response getReadershipForGivenDays(@ApiParam(required = true) @PathParam("applicationId") String applicationId,
                                              @PathParam("duration") int days) {
        validateRequestParams(applicationId);
        return Response.ok(ImmutableMap.of(PAYLOAD, getReadershipAnalytics(days, applicationId))).build();
    }


    private List<ReadershipAnalytics> getReadershipAnalytics(int days, String applicationId) {
        Instant startTime = Instant.now().minus(Duration.ofDays(days));
        Map<String, AtomicInteger> analytics = groupByResourceAndUser(startTime, analyticsRepository.loadReadership());
        ResourceUtil.notFoundIfEmpty(analytics.entrySet(), "Readership not found");

        List<ReadershipAnalytics> readershipForUser = readershipForUser(analytics, applicationId);
        ResourceUtil.notFoundIfEmpty(readershipForUser, "Readership not found");

        return readershipForUser;
    }


    private Map<String, AtomicInteger> groupByResourceAndUser(Instant startTime, Collection<Readership> readerships) {
        Map<String, AtomicInteger> reportMap = new HashMap<>();
        readerships.parallelStream()
                .filter(r -> r.getCreatedAt().isAfter(startTime))
                .collect(Collectors.toMap(r -> r.getResourceId() + "-" + r.getUserId(), Function.identity(), (r1, r2) -> r1))
                .forEach((k, v) -> {
                            reportMap.putIfAbsent(v.getResourceId(), new AtomicInteger(0));
                            reportMap.get(v.getResourceId()).getAndIncrement();
                        }
                );

        return reportMap;
    }


    private List<ReadershipAnalytics> readershipForUser(Map<String, AtomicInteger> analytics, String applicationId) {
        List<ResourceIdentifier> identifiers = analytics.entrySet().stream().map(e -> ResourceIdentifier.builder()
                .resourceId(e.getKey())
                .applicationId(applicationId)
                .classification("Report") //TODO this param should be passed from UI
                .build()).collect(Collectors.toList());

        Map<String, ResourceSummary> summaryMap = contentCacheService.resourceSummariesByClassificationAndResourceId(identifiers, contentCacheContext);
        AtomicInteger sequenceNumber = new AtomicInteger(1);
        return analytics.entrySet().stream().filter(e -> (summaryMap.get(e.getKey()) != null))
                .sorted(Comparator.comparing(e -> e.getValue().intValue(), Comparator.reverseOrder()))
                .limit(TOP_READ_RESULT_LIMIT)
                .map(e -> new ReadershipAnalytics(e.getKey(), e.getKey().replace(PDF, ""), e.getValue().intValue(), sequenceNumber.getAndIncrement()))
                .collect(Collectors.toList());
    }

    public void validateRequestParams(String... requestParams) {
        Stream.of(requestParams).forEach(d ->
                ResourceUtil.badRequestIfNull(d, String.format("Missing request params")));
    }

}
