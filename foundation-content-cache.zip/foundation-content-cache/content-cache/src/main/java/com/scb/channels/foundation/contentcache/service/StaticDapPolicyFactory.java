package com.scb.channels.foundation.contentcache.service;

import com.scb.channels.foundation.entitlement.dap.DapPolicyFactory;

/**
 * Created by 1553709 on 5/17/2017.
 */
public class StaticDapPolicyFactory {

    static DapPolicyFactory INSTANCE ;

    public static void init(DapPolicyFactory delegate) {
        INSTANCE = delegate;
    }
}
