package com.scb.channels.foundation.contentcache.util;

import com.google.common.base.Preconditions;
import com.scb.channels.foundation.util.PropertyIgnoreCase;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.function.Function;

public class FileUtils {

    private static final Logger LOG = LoggerFactory.getLogger(FileUtils.class);

    public static Function<String, String> getFileContent = filename -> {
        try {
            return IOUtils.toString(FileUtils.class.getClassLoader().getResourceAsStream(filename), "UTF-8");
        } catch (IOException e) {
            throw new RuntimeException("Error in reading file", e);
        }
    };

    public static String readFromPropertyFile(String fileName, String key) {
        Preconditions.checkNotNull(fileName, "Property file name not found");
        try {
            PropertyIgnoreCase props = new PropertyIgnoreCase();
            ClassPathResource data = new ClassPathResource(fileName);
            props.load(data.getInputStream());
            return props.getPropertyIgnoreCase(StringUtils.isNotBlank(key) ? key.trim() : "default");
        } catch (IOException e) {
            throw new RuntimeException("Error in reading from property file", e);
        }
    }
}
