package com.scb.channels.foundation.contentcache.api.resource;


import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.AnalyticsRepository;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import com.scb.channels.foundation.contentcache.util.FileUtils;
import com.scb.channels.foundation.util.jackson.Marshaller;
import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.core.MediaType;
import java.io.ByteArrayInputStream;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ContentCacheResourceImplTest {

    @Mock
    private ContentCacheService contentCacheService;

    @Mock
    private Marshaller marshaller;

    @Mock
    private ContentCacheContext contentCacheContext;

    @Mock
    private AnalyticsRepository analyticsRepository;

    @Test
    public void should_track_readership_when_downloading_pdf() {
        ContentCacheResource resource = new ContentCacheResourceImpl(contentCacheService, marshaller, contentCacheContext, analyticsRepository);

        ResourceSummary resourceSummary = ResourceSummary.builder()
                .resourceId("resourceId.pdf")
                .createdAt(Instant.now())
                .applicationId("rp")
                .classification("report")
                .contentType("application/pdf")
                .build();

        ResourceEntity resourceEntity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        when(contentCacheService.resourceByResourceId(any(), any(), any())).thenReturn(resourceEntity);
        resource.getResourceByResourceId("applicationId", "resourceId");
        verify(contentCacheService, times(1)).resourceByResourceId(any(), any(), any());
        verify(analyticsRepository, times(1)).persistReadership(any());
    }

    @Test
    public void should_not_track_readership_when_downloading_image() {
        ContentCacheResource resource = new ContentCacheResourceImpl(contentCacheService, marshaller, contentCacheContext, analyticsRepository);

        ResourceSummary resourceSummary = ResourceSummary.builder()
                .resourceId("resourceId.pdf")
                .createdAt(Instant.now())
                .applicationId("rp")
                .classification("report")
                .contentType("image/jpeg")
                .build();

        ResourceEntity resourceEntity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        when(contentCacheService.resourceByResourceId(any(), any(), any())).thenReturn(resourceEntity);
        resource.getResourceByResourceId("applicationId", "resourceId");
        verify(contentCacheService, times(1)).resourceByResourceId(any(), any(), any());
        verify(analyticsRepository, times(0)).persistReadership(any());
    }
    @Test
    public void should_return_content_type_according_to_extention(){
        String resourceId="Tile|Sleep Away.mp3";
        ResourceSummary resourceSummary = ResourceSummary.builder()
                .resourceId("Tile|Sleep Away.mp3")
                .createdAt(Instant.now())
                .applicationId("rp")
                .classification("report")
                .contentType("application/pdf")
                .build();
        ResourceEntity resourceEntity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        when(contentCacheService.resourceByResourceId(any(), any(), any())).thenReturn(resourceEntity);
        ContentCacheResource resource = new ContentCacheResourceImpl(contentCacheService, marshaller, contentCacheContext, analyticsRepository);
        resource.getResourceByResourceId("applicationId",resourceId);
        assertThat(MediaType.valueOf(FileUtils.readFromPropertyFile("content_type_mapping.properties", FilenameUtils.getExtension(resourceId)))).isEqualTo(MediaType.valueOf("audio/mpeg"));
        assertThat(MediaType.valueOf(FileUtils.readFromPropertyFile("content_type_mapping.properties", FilenameUtils.getExtension("")))).isEqualTo(MediaType.valueOf("application/json"));

    }
}
