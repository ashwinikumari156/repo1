package com.scb.channels.foundation.contentcache.repository;

import com.datastax.driver.core.Session;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.util.TestData;
import com.scb.channels.persistence.PersistenceServiceImpl;
import com.scb.channels.persistence.cassandra.CassandraConfig;
import com.scb.channels.persistence.cassandra.CassandraStore;
import org.apache.thrift.transport.TTransportException;
import org.cassandraunit.utils.EmbeddedCassandraServerHelper;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

public class AnalyticsRepositoryImplTest {

    private static Session session;

    private CassandraConfig cassandraConfig;

    private PersistenceServiceImpl persistenceService;

    private AnalyticsRepositoryImpl analyticsRepository;

    @BeforeClass
    public static void startCassandraAndCreateSchema() throws InterruptedException, IOException, TTransportException {
        EmbeddedCassandraServerHelper.startEmbeddedCassandra(30001);

        InputStream schemaScript = ResourceRepositoryImplTest.class.getClassLoader().getResourceAsStream("test_readership.cql");

        session = EmbeddedCassandraServerHelper.getSession();

        session.execute("CREATE KEYSPACE CONTENT_CACHE WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 1}");
        session.execute("USE CONTENT_CACHE");

        StringBuilder sb = new StringBuilder();
        try(LineNumberReader reader = new LineNumberReader(new InputStreamReader(schemaScript))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                if (line.endsWith(";")) {
                    session.execute(sb.toString());
                    sb.setLength(0);
                }
            }
        }
    }

    @AfterClass
    public static void tearDown() {
        EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
    }

    @Before
    public void setup() {
        cassandraConfig = new CassandraConfig();
        cassandraConfig.setKeyspace("CONTENT_CACHE");
        persistenceService = new PersistenceServiceImpl(new CassandraStore(cassandraConfig, session));
        analyticsRepository = new AnalyticsRepositoryImpl(persistenceService);
        session.execute("TRUNCATE readership_by_id");
    }


    @Test
    public void persistReadership() throws Exception {
        Readership readership = TestData.readership();

        analyticsRepository.persistReadership(readership);
        Collection<Readership> readerships = analyticsRepository.loadReadership();
        readerships.stream().forEach(r -> {
            assertEquals("userId", r.getUserId());
            assertEquals("resourceId", r.getResourceId());
        });
    }
}
