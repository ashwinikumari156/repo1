package com.scb.channels.foundation.contentcache.repository;

import com.datastax.driver.core.ResultSet;
import com.google.common.collect.Iterables;
import com.scb.channels.persistence.Loadable;
import com.scb.channels.persistence.Persistable;
import com.scb.channels.persistence.PersistableBatch;
import com.scb.channels.persistence.PersistableBatchBuilder;
import com.scb.channels.persistence.PersistenceService;
import com.scb.channels.foundation.contentcache.util.TestData;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Date;
import java.util.UUID;

import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public abstract class AbstractRepositoryImplTest {

    public static final String MOCK_COL_VALUE_STRING = "string";

    public static final String MOCK_CONTENT_VALUE = TestData.getContent();

    @Mock
    protected PersistenceService persistenceService;
    @Mock
    protected ResultSet singleRowResult;
    @Mock
    protected com.datastax.driver.core.Row mockRow;

    @Mock
    protected PersistableBatchBuilder batchBuilder;

    @Before
    public void setUp() {
        when(singleRowResult.all()).thenReturn(Collections.singletonList(mockRow));

        mockUnmarshallSingleRow();
    }

    protected void mockUnmarshallSingleRow() {
        when(mockRow.getString(any())).thenReturn(MOCK_COL_VALUE_STRING);
        when(mockRow.getString("content")).thenReturn(MOCK_CONTENT_VALUE);
        when(mockRow.getUUID(any())).thenReturn(UUID.randomUUID());
        when(mockRow.getMap(anyString(), eq(String.class), eq(String.class))).thenReturn(Collections.emptyMap());
        when(mockRow.getInt(any())).thenReturn(10);
        when(mockRow.getTimestamp(any())).thenReturn(new Date());
    }

    @SuppressWarnings("unchecked")
    protected <T> Loadable<T> captureLoadable() {
        ArgumentCaptor<Loadable<T>> loadableCaptor = ArgumentCaptor.forClass(Loadable.class);
        verify(persistenceService).retrieve(loadableCaptor.capture());
        return loadableCaptor.getValue();
    }

    @SuppressWarnings("unchecked")
    protected <T> Persistable<T> captureBatchPersistable() {
        ArgumentCaptor<Persistable<T>> captor = ArgumentCaptor.forClass(Persistable.class);
        verify(batchBuilder).add(captor.capture());

        return captor.getValue();
    }

    @SuppressWarnings("unchecked")
    protected <T> Persistable<T> captureSinglePersistable() {
        ArgumentCaptor<Persistable<T>> captor = ArgumentCaptor.forClass(Persistable.class);
        verify(persistenceService).persist(captor.capture());
        return captor.getValue();
    }

    @SuppressWarnings("unchecked")
    protected <T> Persistable<T> capturePersistableBatchWithSingleEntry() {
        ArgumentCaptor<PersistableBatch> captor = ArgumentCaptor.forClass(PersistableBatch.class);
        verify(persistenceService).persist(captor.capture());
        return (Persistable<T>) Iterables.getOnlyElement(captor.getValue().getPersistables());
    }
}
