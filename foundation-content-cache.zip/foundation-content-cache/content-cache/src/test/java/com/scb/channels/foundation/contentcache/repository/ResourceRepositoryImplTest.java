package com.scb.channels.foundation.contentcache.repository;

import com.datastax.driver.core.Session;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterators;
import com.scb.channels.foundation.contentcache.model.ResourceEntity;
import com.scb.channels.foundation.contentcache.model.ResourceFragment;
import com.scb.channels.foundation.contentcache.model.ResourceIdentifier;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.util.TestData;
import com.scb.channels.persistence.PersistenceServiceImpl;
import com.scb.channels.persistence.cassandra.CassandraConfig;
import com.scb.channels.persistence.cassandra.CassandraStore;
import org.apache.thrift.transport.TTransportException;
import org.assertj.core.api.Assertions;
import org.cassandraunit.utils.EmbeddedCassandraServerHelper;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.ws.rs.core.MediaType;
import java.io.*;
import java.util.Collection;

import static org.junit.Assert.*;

public class ResourceRepositoryImplTest {

    private static Session session;

    private ResourceRepositoryImpl resourceRepository;
    private PersistenceServiceImpl persistenceService;
    private CassandraConfig cassandraConfig;

    @BeforeClass
    public static void startCassandraAndCreateSchema() throws InterruptedException, IOException, TTransportException {
        EmbeddedCassandraServerHelper.startEmbeddedCassandra(30000);

        InputStream schemaScript = ResourceRepositoryImplTest.class.getClassLoader().getResourceAsStream("database/001_schema_create.cql");

        session = EmbeddedCassandraServerHelper.getSession();

        session.execute("CREATE KEYSPACE CONTENT_CACHE WITH replication = {'class':'SimpleStrategy', 'replication_factor' : 1}");
        session.execute("USE CONTENT_CACHE");

        StringBuilder sb = new StringBuilder();
        try(LineNumberReader reader = new LineNumberReader(new InputStreamReader(schemaScript))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                if (line.endsWith(";")) {
                    session.execute(sb.toString());
                    sb.setLength(0);
                }
            }
        }

    }

    @AfterClass
    public static void tearDown() {
        EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
    }

    @Before
    public void setup() {
        cassandraConfig = new CassandraConfig();
        cassandraConfig.setKeyspace("CONTENT_CACHE");
        persistenceService = new PersistenceServiceImpl(new CassandraStore(cassandraConfig, session));
        resourceRepository = new ResourceRepositoryImpl(persistenceService);
        session.execute("TRUNCATE resource_by_id");
    }

    @Test
    public void persistFragment() throws Exception {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, null);
        ResourceIdentifier identifier = TestData.identifier("1");

        ResourceFragment fragment = new ResourceFragment(resourceSummary
                , new ByteArrayInputStream(new byte[1000]),0, true);
        resourceRepository.persistFragment(fragment);

        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId());

        assertNotNull(resourceEntity);
        assertEquals("appId", resourceEntity.getResourceSummary().getApplicationId());
        assertEquals("classification", resourceEntity.getResourceSummary().getClassification());
        assertEquals("subClassification", resourceEntity.getResourceSummary().getSubClassification());
        assertEquals("application/json", resourceEntity.getResourceSummary().getContentType());
        assertEquals(1000, resourceEntity.getContentSize());
        assertArrayEquals(new byte[1000], resourceEntity.getContentAsByteBuffer().array());
    }

    @Test
    public void persistResource() throws Exception {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, null);
        ResourceIdentifier identifier = TestData.identifier("1");

        ResourceEntity entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);
        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId());

        assertEquals("appId", resourceEntity.getResourceSummary().getApplicationId());
        assertEquals("classification", resourceEntity.getResourceSummary().getClassification());
        assertEquals("subClassification", resourceEntity.getResourceSummary().getSubClassification());
        assertEquals("application/json", resourceEntity.getResourceSummary().getContentType());
        assertEquals(1000, resourceEntity.getContentSize());
        assertArrayEquals(new byte[1000], resourceEntity.getContentAsByteBuffer().array());
    }

    @Test
    public void persistResource_duplicate() throws Exception {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, null);
        ResourceIdentifier identifier = TestData.identifier("1");

        ResourceEntity entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);

        entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);
        Collection<ResourceSummary> summaries = resourceRepository.loadSummaryByClassification(identifier);
        assertEquals(1, summaries.size());

        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId());

        assertEquals("appId", resourceEntity.getResourceSummary().getApplicationId());
        assertEquals("classification", resourceEntity.getResourceSummary().getClassification());
        assertEquals("subClassification", resourceEntity.getResourceSummary().getSubClassification());
        assertEquals("application/json", resourceEntity.getResourceSummary().getContentType());
        assertEquals(1000, resourceEntity.getContentSize());
        assertArrayEquals(new byte[1000], resourceEntity.getContentAsByteBuffer().array());
    }

    @Test
    public void loadResourceById() throws Exception {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, null);
        ResourceIdentifier identifier = TestData.identifier("1");

        ResourceEntity entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);

        ResourceFragment fragment = new ResourceFragment(TestData.resourceSummary("3", 1000, null),
                new ByteArrayInputStream(new byte[1000]),0, false);
        resourceRepository.persistFragment(fragment);

        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId());

        assertEquals("appId", resourceEntity.getResourceSummary().getApplicationId());
        assertEquals("classification", resourceEntity.getResourceSummary().getClassification());
        assertEquals("subClassification", resourceEntity.getResourceSummary().getSubClassification());
        assertEquals("application/json", resourceEntity.getResourceSummary().getContentType());
        assertEquals(1000, resourceEntity.getContentSize());
        assertArrayEquals(new byte[1000], resourceEntity.getContentAsByteBuffer().array());

        ResourceIdentifier identifier2 = TestData.identifier("2");
        ResourceIdentifier identifier3 = TestData.identifier("3");
        ResourceEntity resourceEntity2 = resourceRepository.loadResourceById(identifier2.getId());
        assertNull(resourceEntity2);
        ResourceEntity resourceEntity3 = resourceRepository.loadResourceById(identifier3.getId());
        assertNull(resourceEntity3);

        ResourceSummary resourceSummary3 = TestData.resourceSummary("3", 1000, null);

        fragment = new ResourceFragment(resourceSummary3, new ByteArrayInputStream(new byte[1000]),1, true);
        resourceRepository.persistFragment(fragment);
        ResourceEntity resourceEntityFor3 = resourceRepository.loadResourceById(identifier3.getId());
        assertNotNull(resourceEntityFor3);
        assertEquals(2000, resourceEntityFor3.getContentSize() );
    }

    @Test
    public void loadResources() throws Exception {
        ResourceSummary resourceSummary1 = TestData.resourceSummary("1", 1000, null);
        ResourceIdentifier identifier = TestData.identifier("1");

        ResourceEntity entity = new ResourceEntity(resourceSummary1, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);

        ResourceSummary resourceSummary2 = TestData.resourceSummary("2", 1000, null);
        entity = new ResourceEntity(resourceSummary2, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);

        assertEquals(2, resourceRepository.loadSummaryByClassification(identifier).size());
    }

    @Test
    public void loadResourceByClassificationResourceIdContentType() {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, "application/pdf");
        ResourceIdentifier identifier = TestData.identifier("1");
        ResourceEntity entity = new ResourceEntity(resourceSummary, new ByteArrayInputStream(new byte[1000]));
        resourceRepository.persistResource(entity);

        ResourceEntity resourceEntity = resourceRepository.loadResourceById(identifier.getId(), MediaType.APPLICATION_JSON);
        assertNull(resourceEntity);
    }

    @Test
    public void loadResourceByResourceIds() {
        resourceRepository.persistResource(new ResourceEntity( TestData.resourceSummary("1", 1000, "application/pdf"), new ByteArrayInputStream(new byte[1000])));
        resourceRepository.persistResource(new ResourceEntity( TestData.resourceSummary("2", 1000, "application/pdf"), new ByteArrayInputStream(new byte[1000])));

        Collection<ResourceEntity> resourceEntities = resourceRepository.loadResourceByResourceIds(ImmutableList.of("1", "2"));
        assertNotNull(resourceEntities);
        Assertions.assertThat(resourceEntities.size()).isGreaterThan(1);
    }

    @Test
    public void loadResourceSummaries() {
        ResourceSummary resourceSummary = TestData.resourceSummary("1", 1000, null);

        ResourceFragment fragment01 = new ResourceFragment(resourceSummary
                , new ByteArrayInputStream(new byte[1000]),0, false);
        resourceRepository.persistFragment(fragment01);

        ResourceFragment fragment02 = new ResourceFragment(resourceSummary
                , new ByteArrayInputStream(new byte[1000]),1, true);
        resourceRepository.persistFragment(fragment02);



        ResourceFragment fragment11 = new ResourceFragment(TestData.resourceSummary("2", 1000, null)
                , new ByteArrayInputStream(new byte[1000]),0, true);
        resourceRepository.persistFragment(fragment11);

        ResourceIdentifier identifier1 = ResourceIdentifier.builder()
                .applicationId("appId")
                .classification("classification")
                .resourceId("1")
                .build();

        ResourceIdentifier identifier2 = ResourceIdentifier.builder()
                .applicationId("appId")
                .classification("classification")
                .resourceId("2")
                .build();

        Collection<Collection<ResourceSummary>> collections = resourceRepository.loadSummaryListByClsAndResourceId(ImmutableList.of(identifier1, identifier2));
        Collection<ResourceSummary> summary1 = Iterators.get(collections.iterator(), 0);
        Collection<ResourceSummary> summary2 = Iterators.get(collections.iterator(), 1);
        assertEquals("1", summary1.iterator().next().getResourceId());
        assertEquals("2", summary2.iterator().next().getResourceId());
    }

}