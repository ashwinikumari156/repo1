package com.scb.channels.foundation.contentcache.api.resource;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.scb.channels.foundation.contentcache.api.dto.ReadershipAnalytics;
import com.scb.channels.foundation.contentcache.api.dto.ReadershipRawData;
import com.scb.channels.foundation.contentcache.model.Readership;
import com.scb.channels.foundation.contentcache.model.ResourceSummary;
import com.scb.channels.foundation.contentcache.repository.AnalyticsRepository;
import com.scb.channels.foundation.contentcache.service.ContentCacheService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.ws.rs.core.Response;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AnalyticsResourceImplTest {

    @Mock
    private AnalyticsRepository analyticsRepository;

    @Mock
    private ContentCacheService contentCacheService;

    @Test
    public void should_return_all_reads() {
        Instant instant1 = Instant.parse("2017-06-01T02:50:08.668Z");
        Instant instant2 = Instant.parse("2017-06-02T02:50:08.668Z");
        Instant instant3 = Instant.parse("2017-06-03T02:50:08.668Z");
        Instant instant4 = Instant.parse("2017-06-04T02:50:08.668Z");

        ImmutableList<Readership> readership = ImmutableList.of(mockReadership("1", "u1", "r1", instant1),
                mockReadership("1", "u1", "r1", instant2),
                mockReadership("2", "u2", "r2", instant3),
                mockReadership("3", "u1", "r2", instant4)
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, null, null);
        Response response = analyticsResource.getReadership("rp", instant1.toString(), instant4.toString());
        Map<String, List<ReadershipRawData>> map = (Map<String, List<ReadershipRawData>>) response.getEntity();
        assertThat(map.get("payload")).hasSize(2);
    }

    @Test
    public void should_return_readership_count() {
        ImmutableList<Readership> readership = ImmutableList.of(mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("2", "u2", "r2.pdf", Instant.now()),
                mockReadership("3", "u1", "r2.pdf", Instant.now())
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);

        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any()))
                .thenReturn(ImmutableMap.of("r1.pdf", mockResourceSummary("r1"), "r2.pdf", mockResourceSummary("r2")));
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForTheWeek("rp");
        Map<String, List<ReadershipAnalytics>> map = (Map<String, List<ReadershipAnalytics>>) response.getEntity();
        List<ReadershipAnalytics> analytics = map.get("payload");
        assertThat(analytics).hasSize(2);
        assertThat(analytics.get(0).getResourceId()).isEqualTo("r2.pdf");
        assertThat(analytics.get(0).getFormattedResourceId()).isEqualTo("r2");
        assertThat(analytics.get(0).getReadCount()).isEqualTo(2);
        assertThat(analytics.get(1).getResourceId()).isEqualTo("r1.pdf");
        assertThat(analytics.get(1).getFormattedResourceId()).isEqualTo("r1");
        assertThat(analytics.get(1).getReadCount()).isEqualTo(1);
    }


    @Test
    public void should_return_last_7_days_reads() {
        ImmutableList<Readership> readership = ImmutableList.of(
                mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("2", "u2", "r2.pdf", Instant.now().minus(Duration.ofDays(8))),
                mockReadership("3", "u3", "r3.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(10))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(11)))
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any())).thenReturn(ImmutableMap.of(
                "r1.pdf", mockResourceSummary("r1.pdf"),
                "r2.pdf", mockResourceSummary("r2.pdf"),
                "r3.pdf", mockResourceSummary("r3.pdf"),
                "r4.pdf", mockResourceSummary("r4.pdf")));
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForTheWeek("rp");
        Map<String, List<ReadershipAnalytics>> map = (Map<String, List<ReadershipAnalytics>>) response.getEntity();
        List<ReadershipAnalytics> analytics = map.get("payload");
        assertThat(analytics.size()).isEqualTo(2);
        assertThat(analytics.get(0).getFormattedResourceId()).isEqualTo("r1");
        assertThat(analytics.get(1).getFormattedResourceId()).isEqualTo("r4");
    }

    @Test
    public void should_return_only_to_10_results_days_reads() {
        ImmutableList<Readership> readership = ImmutableList.of(
                mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("2", "u2", "r2.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("3", "u3", "r3.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("5", "u5", "r5.pdf", Instant.now().minus(Duration.ofDays(10))),
                mockReadership("6", "u6", "r6.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("7", "u7", "r7.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("8", "u8", "r8.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("9", "u9", "r9.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("10", "u10", "r10.pdf", Instant.now().minus(Duration.ofDays(4))),
                mockReadership("11", "u11", "r11.pdf", Instant.now().minus(Duration.ofDays(2))),
                mockReadership("12", "u12", "r12.pdf", Instant.now().minus(Duration.ofDays(6))),
                mockReadership("13", "u13", "r13.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("14", "u14", "r14.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("15", "u15", "r15.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("16", "u16", "r16.pdf", Instant.now().minus(Duration.ofDays(11)))
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        Map<String, ResourceSummary> summaryMap = new HashMap<>();
        for (int i = 1; i <= 16; i++) {
            summaryMap.put("r" + i + ".pdf", mockResourceSummary("r" + i + ".pdf"));
        }
        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any())).thenReturn(summaryMap);
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForTheWeek("rp");
        Map<String, List<ReadershipAnalytics>> map = (Map<String, List<ReadershipAnalytics>>) response.getEntity();
        List<ReadershipAnalytics> analytics = map.get("payload");
        assertThat(analytics.size()).isEqualTo(10);
    }

    @Test
    public void should_return_result_for_specific_time_period() {
        ImmutableList<Readership> readership = ImmutableList.of(
                mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("2", "u2", "r2.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("3", "u3", "r3.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("5", "u5", "r5.pdf", Instant.now().minus(Duration.ofDays(10))),
                mockReadership("6", "u6", "r6.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("7", "u7", "r7.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("8", "u8", "r8.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("9", "u9", "r9.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("10", "u10", "r10.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("11", "u11", "r11.pdf", Instant.now().minus(Duration.ofDays(11)))
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        Map<String, ResourceSummary> summaryMap = new HashMap<>();
        for (int i = 1; i <= 11; i++) {
            summaryMap.put("r" + i + ".pdf", mockResourceSummary("r" + i + ".pdf"));
        }
        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any())).thenReturn(summaryMap);
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForGivenDays("rp", 3);
        Map<String, List<ReadershipAnalytics>> map = (Map<String, List<ReadershipAnalytics>>) response.getEntity();
        List<ReadershipAnalytics> analytics = map.get("payload");
        assertThat(analytics.size()).isEqualTo(3);
    }

    @Test
    public void should_return_result_top_read_based_on_readCount() {
        ImmutableList<Readership> readership = ImmutableList.of(
                mockReadership("1", "u1", "r1.pdf", Instant.now().minus(Duration.ofDays(10))),
                mockReadership("2", "u2", "r2.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("3", "u3", "r3.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("4", "u4", "r4.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("5", "u5", "r5.pdf", Instant.now().minus(Duration.ofDays(10))),
                mockReadership("6", "u6", "r6.pdf", Instant.now().minus(Duration.ofDays(7))),
                mockReadership("7", "u7", "r11.pdf", Instant.now().minus(Duration.ofDays(5))),
                mockReadership("8", "u8", "r8.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("9", "u9", "r9.pdf", Instant.now().minus(Duration.ofDays(1))),
                mockReadership("10", "u10", "r10.pdf", Instant.now().minus(Duration.ofDays(11))),
                mockReadership("11", "u11", "r7.pdf", Instant.now().minus(Duration.ofDays(3))),
                mockReadership("12", "u12", "r7.pdf", Instant.now().minus(Duration.ofDays(11))),
                mockReadership("13", "u13", "r7.pdf", Instant.now().minus(Duration.ofDays(11))),
                mockReadership("14", "u14", "r7.pdf", Instant.now().minus(Duration.ofDays(11))),
                mockReadership("15", "u17", "r1.pdf", Instant.now().minus(Duration.ofDays(11))),
                mockReadership("16", "u16", "r1.pdf", Instant.now().minus(Duration.ofDays(2)))
        );
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        Map<String, ResourceSummary> summaryMap = new HashMap<>();
        for (int i = 1; i <= 12; i++) {
            summaryMap.put("r" + i + ".pdf", mockResourceSummary("r" + i + ".pdf"));
        }
        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any())).thenReturn(summaryMap);
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForGivenDays("rp", 12);
        Map<String, List<ReadershipAnalytics>> map = (Map<String, List<ReadershipAnalytics>>) response.getEntity();
        List<ReadershipAnalytics> analytics = map.get("payload");
        assertThat(analytics.size()).isEqualTo(10);
        assertThat(analytics.get(0).getReadCount()).isEqualTo(4);
        assertThat(analytics.get(0).getFormattedResourceId()).isEqualTo("r7");
        assertThat(analytics.get(0).getSequenceNumber()).isEqualTo(1);
        assertThat(analytics.get(1).getReadCount()).isEqualTo(3);
        assertThat(analytics.get(1).getFormattedResourceId()).isEqualTo("r1");
        assertThat(analytics.get(1).getSequenceNumber()).isEqualTo(2);

    }


    @Test
    public void should_return_reportIds_which_user_is_entitledTo() {
        ImmutableList<Readership> readership = ImmutableList.of(
                mockReadership("1", "u1", "r1.pdf", Instant.now()),
                mockReadership("2", "u1", "r2.pdf", Instant.now()));
        when(analyticsRepository.loadReadership()).thenReturn(readership);
        when(contentCacheService.resourceSummariesByClassificationAndResourceId(any(), any())).thenReturn(ImmutableMap.of("r1.pdf",
                mockResourceSummary("r1")));
        AnalyticsResourceImpl analyticsResource = new AnalyticsResourceImpl(analyticsRepository, contentCacheService, null);
        Response response = analyticsResource.getReadershipForTheWeek("rp");
        Map<String, List<ReadershipRawData>> map = (Map<String, List<ReadershipRawData>>) response.getEntity();
        assertThat(map.get("payload")).hasSize(1);
    }

    private Readership mockReadership(String id, String userId, String resourceId, Instant createdAt) {
        return Readership.builder()
                .id(id)
                .applicationId("applicationId")
                .resourceId(resourceId)
                .userId(userId)
                .createdAt(createdAt)
                .build();
    }

    private ResourceSummary mockResourceSummary(String resourceId) {
        return ResourceSummary.builder()
                .resourceId(resourceId)
                .build();
    }

}